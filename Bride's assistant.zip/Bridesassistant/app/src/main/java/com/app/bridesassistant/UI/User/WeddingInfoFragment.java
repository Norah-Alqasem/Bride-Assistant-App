package com.app.bridesassistant.UI.User;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.bridesassistant.DataClass.WeddingInfo;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.DateAndTime.CustomDatePickerDialog;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentWeddingInfoBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class WeddingInfoFragment extends Fragment {
    private FragmentWeddingInfoBinding mBinding;
    private String userId;
    private DatabaseReference database;
    private SweetAlertDialog loading;
    private int type=0;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding=FragmentWeddingInfoBinding.inflate(inflater,container,false);


        mBinding.date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });
        mBinding.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               CheckEnterData();
            }
        });
        funLoading();
        getData();
        return mBinding.getRoot();
    }
    private void getData()
    {
        userId= FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
        database= FirebaseDatabase.getInstance().getReference(Content.weddingInfo);
        database.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                loading.dismiss();
                if (snapshot.exists())
                {
                    WeddingInfo info=snapshot.getValue(WeddingInfo.class);
                    mBinding.date.setText(info.getDate());
                    mBinding.place.setText(info.getPlace());
                    mBinding.addButton.setText("Update");
                    mBinding.remindingDate.setVisibility(View.VISIBLE);
                    long days=Content.getDaysReminders(info.getDate());
                    if (days>=0)
                    {
                        mBinding.remindingDate.setText("Remaining until marriage : "+days +" day");
                    }
                    else {
                        mBinding.remindingDate.setText("The wedding date has passed, please update.");
                    }
                    type=1;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void CheckEnterData()
    {
        String data=mBinding.date.getText().toString();
        String place=mBinding.place.getText().toString();
        if (data.equals("Wedding date"))
        {
            funField("please select the wedding date");
        }
        else if (place.isEmpty()){
            funField("please select the wedding place");
        }
        else{
            WeddingInfo info=new WeddingInfo(data,place);
            if (type==1)
            {
                alertDialog(info,"Update Wedding info","Are you sure you went to Update wedding info ?");
            }
            else{
                alertDialog(info,"Adding Wedding info","Are you sure you went to Adding wedding info ?");
            }
        }
    }
    private void alertDialog(WeddingInfo info,String title,String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message);
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                funLoading();
                saveData(info);
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void saveData(WeddingInfo info) {
        database.child(userId).setValue(info).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                loading.dismiss();
                if (type==1)
                {
                    funSuccessfully("Update wedding info Successfully");
                }
                else{
                    funSuccessfully("Adding wedding info Successfully");
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                loading.dismiss();
                if (type==1)
                {
                    funSuccessfully("failed to Update wedding info");
                }
                else{
                    funSuccessfully("failed to Adding wedding info");
                }
            }
        });
    }

    private void showDatePickerDialog() {
        CustomDatePickerDialog datePickerDialog = new CustomDatePickerDialog(
                getActivity(),
                (view, year, month, dayOfMonth) -> {
                    // Handle date selection
                    //10
                    String monthStr=((month+1)<10)?"0"+(month+1): (month+1)+"";
                    String date = year + "/" + monthStr + "/" + dayOfMonth;
                    long delay= Content.getDaysReminders2(date);
                    if(delay>0) {
                        mBinding.date.setText(date);
                    }else{
                        funField("Please select a valid date");
                    }
                },
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        );

        datePickerDialog.show();
    }

    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funField(String message) {
        SweetAlertDialog field = SweetDialog.failed(getContext(), message);
        field.show();
        field.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                field.dismiss();
            }
        });
    }
}