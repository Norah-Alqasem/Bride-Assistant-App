package com.app.bridesassistant.DataClass;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Store implements Parcelable {
    private String storeName,image,email,address,mobileNumber,type,instaLink,tiktokLink,location,storeId;
    private int numberOfRatings;
    private float rating,sumOfRatings;
    private boolean status;

    public Store() {
    }

    public Store(String storeName, String image, String email, String address, String mobileNumber, String type, String instaLink, String tiktokLink, String location, String storeId, int numberOfRatings, float rating, float sumOfRatings, boolean status) {
        this.storeName = storeName;
        this.image = image;
        this.email = email;
        this.address = address;
        this.mobileNumber = mobileNumber;
        this.type = type;
        this.instaLink = instaLink;
        this.tiktokLink = tiktokLink;
        this.location = location;
        this.storeId = storeId;
        this.numberOfRatings = numberOfRatings;
        this.rating = rating;
        this.sumOfRatings = sumOfRatings;
        this.status = status;
    }

    protected Store(Parcel in) {
        storeName = in.readString();
        image = in.readString();
        email = in.readString();
        address = in.readString();
        mobileNumber = in.readString();
        type = in.readString();
        instaLink = in.readString();
        tiktokLink = in.readString();
        location = in.readString();
        storeId = in.readString();
        numberOfRatings = in.readInt();
        rating = in.readFloat();
        sumOfRatings = in.readFloat();
        status = in.readByte() != 0;
    }

    public static final Creator<Store> CREATOR = new Creator<Store>() {
        @Override
        public Store createFromParcel(Parcel in) {
            return new Store(in);
        }

        @Override
        public Store[] newArray(int size) {
            return new Store[size];
        }
    };

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getInstaLink() {
        return instaLink;
    }

    public void setInstaLink(String instaLink) {
        this.instaLink = instaLink;
    }

    public String getTiktokLink() {
        return tiktokLink;
    }

    public void setTiktokLink(String tiktokLink) {
        this.tiktokLink = tiktokLink;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public int getNumberOfRatings() {
        return numberOfRatings;
    }

    public void setNumberOfRatings(int numberOfRatings) {
        this.numberOfRatings = numberOfRatings;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public float getSumOfRatings() {
        return sumOfRatings;
    }

    public void setSumOfRatings(float sumOfRatings) {
        this.sumOfRatings = sumOfRatings;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(storeName);
        dest.writeString(image);
        dest.writeString(email);
        dest.writeString(address);
        dest.writeString(mobileNumber);
        dest.writeString(type);
        dest.writeString(instaLink);
        dest.writeString(tiktokLink);
        dest.writeString(location);
        dest.writeString(storeId);
        dest.writeInt(numberOfRatings);
        dest.writeFloat(rating);
        dest.writeFloat(sumOfRatings);
        dest.writeByte((byte) (status ? 1 : 0));
    }
}
