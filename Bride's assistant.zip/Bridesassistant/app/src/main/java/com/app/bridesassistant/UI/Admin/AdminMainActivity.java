package com.app.bridesassistant.UI.Admin;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.Window;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.app.bridesassistant.R;
import com.app.bridesassistant.Utils.Dialoge.AlertDialogLogin;
import com.app.bridesassistant.Utils.LocalLanguage.HelperLocalLanguage;
import com.app.bridesassistant.databinding.ActivityAdminMainBinding;
import com.google.android.material.navigation.NavigationBarView;

public class AdminMainActivity extends AppCompatActivity {
    private AppBarConfiguration mAppBarConfiguration;
    private NavController navController;
    private ActivityAdminMainBinding mainBinding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        HelperLocalLanguage.setLocale(this,"en");
        mainBinding= ActivityAdminMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());
        setSupportActionBar(mainBinding.toolbar);
        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.stores,R.id.users,R.id.categories)
                .build();
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_auth);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        Window window = getWindow();
        window.setStatusBarColor(getResources().getColor(R.color.color3));

        mainBinding.navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId()==R.id.logout)
                {
                    AlertDialogLogin.alertDialogLogout(AdminMainActivity.this);
                }
                else if(item.getItemId()==R.id.stores){
                    navController.navigate(R.id.stores);
                }
                else if(item.getItemId()==R.id.users){
                    navController.navigate(R.id.users);
                }


                else if(item.getItemId()==R.id.categories){
                    navController.navigate(R.id.categories);
                }
                return true;
            }
        });
    }
    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}