package com.app.bridesassistant.UI.User.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.BudgetItemsModel;
import com.app.bridesassistant.DataClass.RelativesDataClass;
import com.app.bridesassistant.R;

import java.util.ArrayList;

public class BudgetItemsAdapter extends RecyclerView.Adapter<BudgetItemsAdapter.helper> {
    private OnItemClickListener mListener;
    public interface OnItemClickListener{
        void delete(int pos);
    }
    public void setOnItemClickListener(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }
    Context context;
    ArrayList<BudgetItemsModel> arrayList;
    public BudgetItemsAdapter(Context context, ArrayList<BudgetItemsModel> arrayList) {
        this.context = context;
        this.arrayList=arrayList;
    }
    @SuppressLint("NotifyDataSetChanged")
    public void update(ArrayList<BudgetItemsModel> arrayList) {
        this.arrayList=arrayList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_budget_items, parent, false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        holder.name.setText(arrayList.get(position).getItem());
        holder.spent.setText(arrayList.get(position).getSpent()+" SAR");
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.delete(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class helper extends RecyclerView.ViewHolder {
        TextView name,spent;
        Button delete;
        public helper(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.name);
            spent=itemView.findViewById(R.id.spent);
            delete=itemView.findViewById(R.id.delete);
        }
    }
}
