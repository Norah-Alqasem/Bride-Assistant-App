package com.app.bridesassistant.DataClass;

public class BudgetItemsModel {
    private String item,spent,id;

    public BudgetItemsModel() {
    }

    public BudgetItemsModel(String item, String spent, String id) {
        this.item = item;
        this.spent = spent;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getSpent() {
        return spent;
    }

    public void setSpent(String spent) {
        this.spent = spent;
    }
}
