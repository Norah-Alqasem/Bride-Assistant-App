package com.app.bridesassistant.UI.Admin.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.R;

import java.util.ArrayList;

public class AdminCategoriesAdapter extends RecyclerView.Adapter<AdminCategoriesAdapter.helper> {
    private OnItemClickListener mListener;
    public interface OnItemClickListener{
        void update(int pos);
        void delete(int pos);
    }
    public void setOnItemClickListener(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }
    Context context;
    ArrayList<Category> categories;
    public AdminCategoriesAdapter(Context context, ArrayList<Category> categories) {
        this.context = context;
        this.categories=categories;
    }

    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_admin_categories, parent, false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        holder.name.setText(categories.get(position).getName());
        holder.Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               mListener.update(position);
            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.delete(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    public class helper extends RecyclerView.ViewHolder {
        TextView name;
        Button Update,delete;
        public helper(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.category);

            Update=itemView.findViewById(R.id.Update);
            delete=itemView.findViewById(R.id.delete);
        }
    }
}
