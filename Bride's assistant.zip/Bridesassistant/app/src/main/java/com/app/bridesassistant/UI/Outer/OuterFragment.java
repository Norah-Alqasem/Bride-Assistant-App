package com.app.bridesassistant.UI.Outer;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.CategoriesRepo;
import com.app.bridesassistant.Utils.EventBus.MessageEvent;
import com.app.bridesassistant.databinding.FragmentOuterBinding;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

public class OuterFragment extends Fragment {
    private FragmentOuterBinding mBinding;
    private int[] layouts;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding=FragmentOuterBinding.inflate(inflater,container,false);
        layouts = new int[]{
                R.layout.slide1,
                R.layout.slide2,
                R.layout.slide3

        };

        // Set adapter
        WelcomePagerAdapter welcomePagerAdapter = new WelcomePagerAdapter(layouts);
        mBinding.viewPager.setAdapter(welcomePagerAdapter);
        welcomePagerAdapter.setButtonClickListener(new WelcomePagerAdapter.OnButtonClickListener() {
            @Override
            public void onButtonClicked(int position) {
                if (position == 2) {
                    Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_auth).navigate(R.id.action_outer_to_stores);
                    EventBus.getDefault().postSticky(new MessageEvent("1"));

                    //startActivity(new Intent(OuterMainActivity.this, AuthMainActivity.class));
                }
                else{
                    welcomePagerAdapter.notifyItemMoved(position,position+1);
                }
            }
        });


        return mBinding.getRoot();
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}