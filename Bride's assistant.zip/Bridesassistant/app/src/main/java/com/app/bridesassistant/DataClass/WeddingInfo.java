package com.app.bridesassistant.DataClass;

public class WeddingInfo {
    private String date,place;

    public WeddingInfo(String date, String place) {
        this.date = date;
        this.place = place;
    }

    public WeddingInfo() {
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }
}
