package com.app.bridesassistant.UI.User.Relatives;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.app.bridesassistant.DataClass.RelativesDataClass;
import com.app.bridesassistant.Repo.RelativesRepo;
import com.app.bridesassistant.UI.User.Adapters.RelativesAdapter;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentRelativesBinding;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.UUID;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class RelativesFragment extends Fragment {
    private FragmentRelativesBinding mBinding;
    private String userId;
    private SweetAlertDialog loading;
    private ArrayList<RelativesDataClass> arrayList;
    private RelativesAdapter adapter;
    private RelativesRepo repo;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentRelativesBinding.inflate(inflater, container, false);
        funLoading();
        repo = new RelativesRepo();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
        clickAdd();
        defineItems();
        clickItem();
        return mBinding.getRoot();
    }

    private void defineItems() {
        arrayList = new ArrayList<>();
        adapter = new RelativesAdapter(getActivity(), arrayList);
        mBinding.relatives.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.relatives.setAdapter(adapter);
        getDataFromFirebase();
    }

    private void getDataFromFirebase() {
        repo.getAllRelatives(userId).observe(getViewLifecycleOwner(), tasks -> {
            loading.dismiss();
            arrayList.clear();
            arrayList.addAll(tasks);
            if (arrayList.isEmpty())
                mBinding.empty.setVisibility(View.VISIBLE);
            else
                mBinding.empty.setVisibility(View.GONE);

            adapter.notifyDataSetChanged();
        });
    }

    private void clickAdd() {
        mBinding.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = mBinding.name.getText().toString();
                String relationship = mBinding.relationship.getText().toString();
                if (name.isEmpty()) {
                    mBinding.name.setError("Please enter the task Name");
                } else if (relationship.isEmpty()) {
                    mBinding.relationship.setError("Please the enter the relationship");
                } else {
                    funLoading();
                    String id = UUID.randomUUID().toString();
                    RelativesDataClass dataClass = new RelativesDataClass(name, relationship, id);
                    saveToDatabase(dataClass);
                }
            }
        });
    }

    private void saveToDatabase(RelativesDataClass dataClass) {
        repo.saveRelativeData(dataClass,userId).observe(getViewLifecycleOwner(),result->
        {
            loading.dismiss();
            if (result.equals("failed"))
            {
                funField("Failed to add Relative please try again ");
            }
            else {
                funSuccessfully("adding successfully");
            }
        });
    }

    private void clickItem() {
        adapter.setOnItemClickListener(new RelativesAdapter.OnItemClickListener() {
            @Override
            public void delete(int pos) {
                alertDialog(pos, "Delete Relative", "Are you sure you need to Delete this Relative?");
            }
        });
    }

    private void alertDialog(int position, String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message);
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                deleteItem(position, title);
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void deleteItem(int position, String title) {
        repo.deleteRelativeData(arrayList.get(position).getId(),userId).observe(getViewLifecycleOwner(),result->
        {
            loading.dismiss();
            if (result.equals("failed"))
            {
                funField("Failed to "+title );
            }
            else {
                funSuccessfully(title+" Successfully");
            }
        });
    }

    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
        mBinding.relationship.setText("");
        mBinding.name.setText("");
    }

    private void funField(String message) {
        SweetAlertDialog field = SweetDialog.failed(getContext(), message);
        field.show();
        field.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                field.dismiss();
            }
        });
    }

}