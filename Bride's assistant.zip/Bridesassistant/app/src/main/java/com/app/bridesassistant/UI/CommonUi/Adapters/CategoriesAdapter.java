package com.app.bridesassistant.UI.CommonUi.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.R;

import java.util.ArrayList;

public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.helper> {

    private ArrayList<Category> categories;
    private Context context;
    private int selectedPosition = 0;

    public interface OnItemClickListener
    {
        void viewStores(int position);
    }
    private OnItemClickListener mListener;
    public  void onclickItem(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }

    public CategoriesAdapter(ArrayList<Category> categories, Context context) {
        this.categories = categories;
        this.context = context;
    }
    @SuppressLint("NotifyDataSetChanged")
    public void  navigateTo(int i)
    {
        selectedPosition=i;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_categories,parent,false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        holder.name.setText(categories.get(position).getName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update the selected position
                selectedPosition = position;
                notifyDataSetChanged();
                mListener.viewStores(position);
            }
        });

        // Change the background based on the selected position
        if (selectedPosition == position) {
            holder.itemView.setSelected(true);
            holder.itemView.setBackgroundResource(R.drawable.view_background1);
        } else {
            holder.itemView.setSelected(false);
            holder.itemView.setBackgroundResource(R.drawable.view_background);
        }
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    public class helper extends RecyclerView.ViewHolder{
        private TextView name;
        public helper(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.title);
        }
    }
}