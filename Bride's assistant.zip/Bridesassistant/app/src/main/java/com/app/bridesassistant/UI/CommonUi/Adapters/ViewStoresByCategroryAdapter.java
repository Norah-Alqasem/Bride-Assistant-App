package com.app.bridesassistant.UI.CommonUi.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.R;

import java.util.ArrayList;

public class ViewStoresByCategroryAdapter extends RecyclerView.Adapter<ViewStoresByCategroryAdapter.helper> {
    public interface OnItemClickListener
    {
        void viewDetails(int position);
        void viewInstagram(int position);
        void viewTiktok(int position);
        void viewMakeCall(int position);
    }
    private OnItemClickListener mListener;
    public  void onclickItem(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }
    private ArrayList<Store> stores;

    public ViewStoresByCategroryAdapter(Context context, ArrayList<Store> stores) {
        this.stores=stores;

    }
    @SuppressLint("NotifyDataSetChanged")
    public void updateData(ArrayList<Store> stores)
    {
        this.stores=stores;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_user_stores, parent, false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        Store store=stores.get(position);
        holder.name.setText(store.getStoreName());
        holder.type.setText(store.getType()+ " store");
        holder.address.setText(store.getAddress());
        holder.rating_text.setText(store.getRating()+"");
        holder.rating_bar.setRating(store.getRating());
        if (!store.getImage().isEmpty())
        {
            Bitmap decodedBitmap = decodeBase64ToBitmap(store.getImage());
            holder.image.setImageBitmap(decodedBitmap);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.viewDetails(position);
            }
        });
        holder.insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.viewInstagram(position);
            }
        });
        holder.tiktok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.viewTiktok(position);
            }
        });
        holder.call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.viewMakeCall(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return stores.size();
    }

    public class helper extends RecyclerView.ViewHolder {
        private ImageView image,insta,tiktok,call;
        private TextView name,address,type,rating_text;
        private RatingBar rating_bar;
        public helper(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image);
            insta = itemView.findViewById(R.id.insta);
            tiktok = itemView.findViewById(R.id.tiktok);
            call = itemView.findViewById(R.id.phone);
            name = itemView.findViewById(R.id.name);
            address = itemView.findViewById(R.id.address);
            type = itemView.findViewById(R.id.type);
            rating_text = itemView.findViewById(R.id.rating_text);

            rating_bar = itemView.findViewById(R.id.rating_bar);

        }
    }
    private Bitmap decodeBase64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}
