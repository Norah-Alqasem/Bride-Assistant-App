package com.app.bridesassistant.DataClass;

public class TaskDataclass {
    private String taskName,taskTime,taskDate,taskId;

    public TaskDataclass() {
    }

    public TaskDataclass(String taskName, String taskTime, String taskDate, String taskId) {
        this.taskName = taskName;
        this.taskTime = taskTime;
        this.taskDate = taskDate;
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskTime() {
        return taskTime;
    }

    public void setTaskTime(String taskTime) {
        this.taskTime = taskTime;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }
}
