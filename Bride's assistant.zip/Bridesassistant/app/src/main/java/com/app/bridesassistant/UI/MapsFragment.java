package com.app.bridesassistant.UI;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.bridesassistant.R;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.databinding.FragmentMapsBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class MapsFragment extends Fragment {

    private FragmentMapsBinding mapsBinding;
    private OnMapReadyCallback callback = googleMap -> {
        viewLocations(26.4207,50.0888,"Dammam",googleMap);
        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                notifyLocation(latLng);
            }
        });
    };
    private void notifyLocation(LatLng latLng) {
        Log.d("touristicPlaces", latLng.longitude + "");
        //Success
        SweetAlertDialog pDialogSuccess = new SweetAlertDialog(getActivity(), SweetAlertDialog.NORMAL_TYPE);
        pDialogSuccess.setTitleText("Do you want to choose this place?");
        pDialogSuccess.setConfirmText("Yes");
        pDialogSuccess.setCancelText("No");
        pDialogSuccess.setConfirmClickListener(sweetAlertDialog -> {
            Content.location = String.valueOf(latLng.latitude) + "," + String.valueOf(latLng.longitude);
            pDialogSuccess.dismiss();
            getActivity().getSupportFragmentManager().beginTransaction().remove(MapsFragment.this).commit();
        });
        pDialogSuccess.setCancelClickListener(sweetAlertDialog ->
        {
            pDialogSuccess.dismiss();
        });
        pDialogSuccess.setCancelable(false);
        pDialogSuccess.show();
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mapsBinding=FragmentMapsBinding.inflate(inflater,container,false);


        return mapsBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(callback);
        }
    }
    private void viewLocations(double latitude, double longitude, String title, GoogleMap googleMap)
    {
        LatLng location = new LatLng(latitude, longitude);
        googleMap.addMarker(new MarkerOptions().position(location).title(title).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 17));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}