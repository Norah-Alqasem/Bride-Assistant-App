package com.app.bridesassistant.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Content {
    public static int type = 0;
    public static int categoryNum = 0;
    public static String location = "location";


    public static String userTable = "users";
    public static String storesTable = "stores";
    public static String categoriesTable = "categories";
    public static String taskTable = "tasks";
    public static String relativesTable = "relatives";
    public static String commentTable = "Comments";
    public static String weddingInfo = "weddingInfo";
    public static String budget = "budget";
    public static String budgetItems = "budgetItems";

    public static long calculateDelay(String currentTime, String time) {
        try {
            //8:00:00
            //12:00:00
            SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
            Date date1 = format.parse(currentTime);
            Date date2 = format.parse(time);

            return (date2.getTime() - date1.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return -1;
        }

    }
    public static String getCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());
        String currentDate = dateFormat.format(Calendar.getInstance().getTime());
        return currentDate;
    }
    public static long getDaysReminders(String endDate) {
        //9/3/25
        //8/3/25
        //-1
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());

        try {
            long startMillis = sdf.parse(getCurrentDate()).getTime();
            long endMillis = sdf.parse(endDate).getTime();

            long diffMillis = endMillis- startMillis;
            long days= TimeUnit.MILLISECONDS.toDays(diffMillis);
            return days ; // Convert milliseconds to days
        } catch (ParseException e) {
            e.printStackTrace();
            return -1; // Error case
        }
    }

    public static long getDaysReminders2(String endDate) {
        //9/3/25
        //8/3/25
        //-1
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());

        try {
            long startMillis = sdf.parse(getCurrentDate()).getTime();
            long endMillis = sdf.parse(endDate).getTime();

            long diffMillis = endMillis- startMillis;
            long days= TimeUnit.MILLISECONDS.toDays(diffMillis);
            if (days<0)
            {
                days=0;
            }
            return days ; // Convert milliseconds to days
        } catch (ParseException e) {
            e.printStackTrace();
            return -1; // Error case
        }
    }

}
