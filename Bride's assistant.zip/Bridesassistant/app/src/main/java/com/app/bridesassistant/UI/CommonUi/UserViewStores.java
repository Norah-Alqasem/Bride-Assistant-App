package com.app.bridesassistant.UI.CommonUi;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.CategoriesRepo;
import com.app.bridesassistant.Repo.StoreRepo;
import com.app.bridesassistant.UI.CommonUi.Adapters.CategoriesAdapter;
import com.app.bridesassistant.UI.CommonUi.Adapters.ViewStoresByCategroryAdapter;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.Utils.EventBus.MessageEvent;
import com.app.bridesassistant.databinding.FragmentUserViewStoresBinding;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class UserViewStores extends Fragment {
    private FragmentUserViewStoresBinding mBinding;
    private ViewStoresByCategroryAdapter categroryStoreAdapter;
    CategoriesAdapter adapter;
    ArrayList<Category> categories;
    private SweetAlertDialog loading;
    private ArrayList<Store> stores,arrayList=new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentUserViewStoresBinding.inflate(inflater, container, false);
        stores=new ArrayList<>();
        allCategories();
        defineRecyclerStores();
        funLoading();
        clickStore();
        return mBinding.getRoot();
    }
    private void defineRecyclerStores()
    {
        categroryStoreAdapter=new ViewStoresByCategroryAdapter(getActivity(),stores);
        mBinding.stores.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.stores.setAdapter(categroryStoreAdapter);
    }


    private void allCategories() {
        categories = new ArrayList<>();
        adapter = new CategoriesAdapter(categories, getActivity());
        mBinding.allCategoriesRecycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        mBinding.allCategoriesRecycler.setAdapter(adapter);
        adapter.onclickItem(new CategoriesAdapter.OnItemClickListener() {
            @Override
            public void viewStores(int position) {
                Content.categoryNum=position;
                viewStoreByCategory(categories.get(position).getName());
            }
        });
        CategoriesRepo repo = new CategoriesRepo();
        repo.getAllCategories().observe(getViewLifecycleOwner(), result -> {
            loading.dismiss();
            categories.addAll(result);
            if (result.isEmpty())
            {
                categories.add(new Category("No Categories","1"));
            }
            adapter.notifyDataSetChanged();
            getAllStores();
        });

    }

    private void getAllStores()
    {
        StoreRepo repo=new StoreRepo();
        repo.getAllStores().observe(getViewLifecycleOwner(),result->{
            loading.dismiss();
            stores.clear();
            if (result.isEmpty())
            {
                mBinding.empty2.setVisibility(View.VISIBLE);
            }
            else {
                for (Store s:result)
                {
                    if (!s.isStatus()) {
                        stores.add(s);
                    }
                }
                adapter.navigateTo(Content.categoryNum);
                mBinding.allCategoriesRecycler.scrollToPosition(Content.categoryNum);
                viewStoreByCategory(categories.get(Content.categoryNum).getName());
            }

        });
    }
    private void viewStoreByCategory(String category)
    {
        arrayList.clear();
        for (Store s : stores)
        {
            if (s.getType().toLowerCase().equals(category.toLowerCase()))
            {
                arrayList.add(s);
            }
        }
        if (arrayList.isEmpty())
        {
            mBinding.empty2.setVisibility(View.VISIBLE);
        }
        else{
            mBinding.empty2.setVisibility(View.GONE);
        }
        categroryStoreAdapter.updateData(arrayList);

    }
    private void clickStore()
    {
        categroryStoreAdapter.onclickItem(new ViewStoresByCategroryAdapter.OnItemClickListener() {
            @Override
            public void viewDetails(int position) {
                Bundle b=new Bundle();
                b.putParcelable("data",arrayList.get(position));
                if (Content.type == 0)
                    Navigation.findNavController(getActivity(), R.id.nav_host_fragment_activity_auth).navigate(R.id.action_stores_to_storeDetails,b);
                else{
                    Navigation.findNavController(getActivity(), R.id.nav_host_fragment_activity_auth).navigate(R.id.action_stores_to_storeDetails2,b);
                }
            }

            @Override
            public void viewInstagram(int position) {
                openLink(arrayList.get(position).getInstaLink());
            }

            @Override
            public void viewTiktok(int position) {
                Log.e("link",arrayList.get(position).getTiktokLink());
                openLink(arrayList.get(position).getTiktokLink());
            }

            @Override
            public void viewMakeCall(int position) {
                Log.e("call",arrayList.get(position).getMobileNumber());
                call(arrayList.get(position).getMobileNumber());
            }
        });
    }
    private void openLink(String url)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    private void call(String phoneNumber) {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE}, 1);
        } else {
            // Permission already granted, make the call
            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:" + phoneNumber));
            if (dialIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                startActivity(dialIntent);
            } else {
                // Handle the case where no dialer is available
                Toast.makeText(getActivity(), "No dialer app found!", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (Content.type==0) {
            EventBus.getDefault().postSticky(new MessageEvent("2"));
        }
    }
}