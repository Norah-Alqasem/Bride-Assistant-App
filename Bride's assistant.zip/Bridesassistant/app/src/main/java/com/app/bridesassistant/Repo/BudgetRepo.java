package com.app.bridesassistant.Repo;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.BudgetModel;
import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class BudgetRepo {
    private DatabaseReference database;

    public BudgetRepo() {
        database=FirebaseDatabase.getInstance().getReference(Content.budget);
    }
    public LiveData<BudgetModel> get(String userId)
    {
        MutableLiveData<BudgetModel> liveData=new MutableLiveData<>();

        database.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists())
                {
                    BudgetModel c=snapshot.getValue(BudgetModel.class);
                    liveData.postValue(c);
                }
                else{
                    liveData.postValue(new BudgetModel());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }
    public LiveData<String> saveData(BudgetModel b,String userid)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(userid).setValue(b)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }

}
