package com.app.bridesassistant.UI.CommonUi.Adapters;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.Comment;
import com.app.bridesassistant.R;

import java.util.ArrayList;

public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.helper> {
    ArrayList<Comment> arrayList;
    public CommentsAdapter(ArrayList<Comment> arrayList) {
        this.arrayList=arrayList;
    }

    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_comments,parent,false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        Comment c=arrayList.get(position);
        holder.commnt.setText(c.getComment());
        holder.username.setText(c.getUsername());
        holder.date.setText(c.getDate());

        if (!c.getImage().isEmpty())
        {
            Bitmap decodedBitmap = decodeBase64ToBitmap(c.getImage());
            holder.image.setImageBitmap(decodedBitmap);
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class helper extends RecyclerView.ViewHolder{
        private TextView commnt ,username,date;
        ImageView image;
        public helper(@NonNull View itemView) {
            super(itemView);
            commnt=itemView.findViewById(R.id.comment);
            date=itemView.findViewById(R.id.date);
            username=itemView.findViewById(R.id.userName);
            image=itemView.findViewById(R.id.profileImage);
        }
    }
    private Bitmap decodeBase64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}