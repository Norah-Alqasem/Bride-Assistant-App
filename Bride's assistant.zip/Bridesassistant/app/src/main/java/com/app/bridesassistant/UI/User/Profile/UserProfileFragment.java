package com.app.bridesassistant.UI.User.Profile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;


import com.app.bridesassistant.DataClass.User;
import com.app.bridesassistant.Repo.UsersRepo;
import com.app.bridesassistant.Utils.CheckPermissionToOpenGallery;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.Utils.Validation.PasswordValidation;
import com.app.bridesassistant.Utils.Validation.ValidationPhoneNumber;
import com.app.bridesassistant.databinding.FragmentUserProfileBinding;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class UserProfileFragment extends Fragment {
    private FragmentUserProfileBinding mBinding;
    private User user;
    private UsersRepo repo;
    private SweetAlertDialog loading;
    private FirebaseAuth auth;
    private String image = "", userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentUserProfileBinding.inflate(inflater, container, false);
        auth = FirebaseAuth.getInstance();
        userId = auth.getCurrentUser().getUid().toString();
        repo = new UsersRepo();
        funLoading();
        getUserData();
        mBinding.update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkEnteredStoreData();
            }
        });
        mBinding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CheckPermissionToOpenGallery.checkThePermission(getActivity()))
                    openGallery();
            }
        });
        return mBinding.getRoot();
    }

    private void getUserData() {
        repo.getUserData(userId).observe(getViewLifecycleOwner(), result -> {
            loading.dismiss();
            user = result;
            addDataToDesign();
        });
    }

    private void addDataToDesign() {
        mBinding.useName.setText(user.getUserName());
        mBinding.email.setText(user.getEmail());
        mBinding.userPhoneNumber.setText(user.getPhoneNumber());
        mBinding.userAddress.setText(user.getAddress());
        if (!user.getImage().isEmpty()) {
            Bitmap decodedBitmap = decodeBase64ToBitmap(user.getImage());
            mBinding.profileImage.setImageBitmap(decodedBitmap);
            image = user.getImage();
        }
    }

    private Bitmap decodeBase64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

    private void checkEnteredStoreData() {
        String name = mBinding.useName.getText().toString();
        String phone = mBinding.userPhoneNumber.getText().toString();
        String address = mBinding.userAddress.getText().toString();
        if (name.isEmpty()) {
            mBinding.useName.setError("Add username");
        } else if (!ValidationPhoneNumber.validatePhoneNumber(phone)) {
            mBinding.userPhoneNumber.setError("Please make sure the number is correct as it starts with (05) and consists of 10 digits.");
        } else if (address.isEmpty()) {
            mBinding.userAddress.setError("Add the title");
        } else {
            funLoading();
            user.setImage(image);
            user.setUserName(name);
            user.setPhoneNumber(phone);
            user.setAddress(address);
            saveData();
        }
    }

    private void saveData() {

        repo.saveUserData(user).observe(getViewLifecycleOwner(), status -> {
            loading.dismiss();
            if (status.equals("failed")) {
                funFailed("Failed to update account Please change your email");
            } else {
                funSuccessfully("Update account successfully");
            }
        });
    }

    private void openGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), 1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Glide.with(getActivity()).load(data.getData().toString()).into(mBinding.profileImage);
                Uri selectedImageUri = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImageUri);
                    image = convertToBase64(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private String convertToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funFailed(String message) {
        SweetAlertDialog failed = SweetDialog.failed(getContext(), message);
        failed.show();
        failed.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                failed.dismiss();
            }
        });
    }
}