package com.app.bridesassistant.UI.Outer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.R;

public class WelcomePagerAdapter extends RecyclerView.Adapter<WelcomePagerAdapter.WelcomeViewHolder> {

    private final int[] layouts;
    private OnButtonClickListener buttonClickListener;

    public WelcomePagerAdapter(int[] layouts) {
        this.layouts = layouts;
    }
    public void setButtonClickListener(OnButtonClickListener buttonClickListener)
    {
        this.buttonClickListener=buttonClickListener;
    }
    @NonNull
    @Override
    public WelcomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(viewType, parent, false);
        return new WelcomeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WelcomeViewHolder holder, int position) {
        // No binding necessary since layout files are static
        holder.bind(position, buttonClickListener);
    }

    @Override
    public int getItemCount() {
        return layouts.length;
    }

    @Override
    public int getItemViewType(int position) {
        return layouts[position];
    }

    public class WelcomeViewHolder extends RecyclerView.ViewHolder {
        public WelcomeViewHolder(@NonNull View itemView) {
            super(itemView);
        }
        void bind(int position, OnButtonClickListener buttonClickListener) {
            ImageView button = itemView.findViewById(R.id.skip);
            button.setOnClickListener(v -> buttonClickListener.onButtonClicked(position));
        }
    }
    public interface OnButtonClickListener {
        void onButtonClicked(int position);
    }
}

