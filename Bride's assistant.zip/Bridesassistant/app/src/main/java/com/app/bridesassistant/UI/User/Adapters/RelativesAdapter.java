package com.app.bridesassistant.UI.User.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.RelativesDataClass;
import com.app.bridesassistant.R;

import java.util.ArrayList;

public class RelativesAdapter extends RecyclerView.Adapter<RelativesAdapter.helper> {
    private OnItemClickListener mListener;
    public interface OnItemClickListener{
        void delete(int pos);
    }
    public void setOnItemClickListener(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }
    Context context;
    ArrayList<RelativesDataClass> arrayList;
    public RelativesAdapter(Context context, ArrayList<RelativesDataClass> arrayList) {
        this.context = context;
        this.arrayList=arrayList;
    }

    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_relatives, parent, false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        holder.name.setText(arrayList.get(position).getName());
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.delete(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class helper extends RecyclerView.ViewHolder {
        TextView name;
        Button delete;
        public helper(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.name);
            delete=itemView.findViewById(R.id.delete);
        }
    }
}
