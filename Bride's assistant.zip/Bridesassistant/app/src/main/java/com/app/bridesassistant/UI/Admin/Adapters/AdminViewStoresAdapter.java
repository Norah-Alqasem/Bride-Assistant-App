package com.app.bridesassistant.UI.Admin.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.R;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class AdminViewStoresAdapter extends RecyclerView.Adapter<AdminViewStoresAdapter.helper> {
    public interface OnItemClickListener
    {
        void update(int position);
        void block(int position);
    }
    private OnItemClickListener mListener;
    public  void onclickItem(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }



    Context context;
    private ArrayList<Store> stores;
    public AdminViewStoresAdapter(Context context, ArrayList<Store> stores) {
        this.context = context;
        this.stores=stores;
    }
    @SuppressLint("NotifyDataSetChanged")
    public void updateData(ArrayList<Store> stores) {
        this.stores=stores;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_admin_view_stores, parent, false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        Store store=stores.get(position);
        holder.name.setText(store.getStoreName());
        holder.type.setText(store.getType()+ " store");
        holder.address.setText(store.getAddress());
        if (!store.getImage().isEmpty())
        {
            Bitmap decodedBitmap = decodeBase64ToBitmap(store.getImage());
            holder.image.setImageBitmap(decodedBitmap);
        }
        holder.update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.update(position);
            }
        });
        holder.block.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.block(position);
            }
        });
        if (store.isStatus())
        {
            holder.block.setText("UnBlock");
        }
        else{
            holder.block.setText("Block");
        }
    }

    @Override
    public int getItemCount() {
        return stores.size();
    }

    public class helper extends RecyclerView.ViewHolder {
        private ImageView image;
        private TextView name,address,type;
        Button update,block;
        public helper(@NonNull View itemView) {
            super(itemView);
            update=itemView.findViewById(R.id.update);
            block=itemView.findViewById(R.id.block);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            address = itemView.findViewById(R.id.address);
            type = itemView.findViewById(R.id.type);
        }
    }
    private Bitmap decodeBase64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}
