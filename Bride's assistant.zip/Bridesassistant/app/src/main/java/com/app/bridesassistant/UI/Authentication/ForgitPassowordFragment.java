package com.app.bridesassistant.UI.Authentication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;


import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentForgitPassowordBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class ForgitPassowordFragment extends Fragment {
    private FragmentForgitPassowordBinding mBinding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding=FragmentForgitPassowordBinding.inflate(inflater,container,false);

        mBinding.send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=mBinding.signInEmail.getText().toString();
                if (email.isEmpty())
                {
                    mBinding.signInEmail.setError("Enter your email");
                }
                else{
                    sendEmail(email);
                }
            }
        });
        return mBinding.getRoot();
    }
    private void sendEmail(String email)
    {
        FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            funLoginSuccessfully();
                        } else {
                            funLoginField("Failed to send email. Please try again.");
                        }
                    }
                });
    }
    private void funLoginSuccessfully() {
        SweetAlertDialog success = SweetDialog.success(getContext(), "Email sent successfully");
        success.show();
    }

    private void funLoginField(String message) {
        SweetAlertDialog field = SweetDialog.failed(getContext(), message);
        field.show();
        field.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                field.dismiss();
            }
        });
    }
}