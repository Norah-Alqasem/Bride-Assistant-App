package com.app.bridesassistant.DataClass;

public class Comment {
    String comment,userId,username,image,date,id;

    public Comment(String comment, String userId, String username, String image, String date, String id) {
        this.comment = comment;
        this.userId = userId;
        this.username = username;
        this.image = image;
        this.date = date;
        this.id = id;
    }

    public Comment() {
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
