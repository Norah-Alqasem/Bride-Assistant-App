package com.app.bridesassistant.UI.Admin.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.User;
import com.app.bridesassistant.R;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class AdminViewUsersAdapter extends RecyclerView.Adapter<AdminViewUsersAdapter.helper> {
    public interface OnItemClickListener
    {
        void block(int position);
    }
    private OnItemClickListener mListener;
    public  void onclickItem(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }


    Context context;
    ArrayList<User> users;

    public AdminViewUsersAdapter(Context context, ArrayList<User> users) {
        this.context = context;
        this.users=users;
    }
    @SuppressLint("NotifyDataSetChanged")
    public void updateData(ArrayList<User> users) {
        this.users=users;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_admin_view_users, parent, false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        User user=users.get(position);
        holder.name.setText(user.getUserName());
        holder.address.setText(user.getAddress());
        holder.email.setText(user.getEmail());
        if (!user.getImage().isEmpty())
        {
            Glide.with(context).load(user.getImage()).into(holder.image);
        }
        holder.block.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.block(position);
            }
        });
        if (user.isStatus())
        {
            holder.block.setText("UnBlock");
        }
        else{
            holder.block.setText("Block");
        }
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class helper extends RecyclerView.ViewHolder {
        Button block;
        TextView name,email,address;
        ImageView image;
        public helper(@NonNull View itemView) {
            super(itemView);
            block=itemView.findViewById(R.id.block);

            name=itemView.findViewById(R.id.name);
            email=itemView.findViewById(R.id.email);
            address=itemView.findViewById(R.id.address);
            image=itemView.findViewById(R.id.image);

        }
    }
}
