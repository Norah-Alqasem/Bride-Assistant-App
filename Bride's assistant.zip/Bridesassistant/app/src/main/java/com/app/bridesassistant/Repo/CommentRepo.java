package com.app.bridesassistant.Repo;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.Comment;
import com.app.bridesassistant.DataClass.RelativesDataClass;
import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.DataClass.User;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CommentRepo {
    private DatabaseReference database;

    public CommentRepo() {
        database=FirebaseDatabase.getInstance().getReference(Content.commentTable);
    }

    public LiveData<ArrayList<Comment>> getAllComments(String storeId) {
        MutableLiveData<ArrayList<Comment>> liveData = new MutableLiveData<>();
        ArrayList<Comment> comments = new ArrayList<>();
        database.child(storeId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                comments.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot data : snapshot.getChildren()) {
                        Comment c = data.getValue(Comment.class);
                        comments.add(c);
                    }
                    liveData.postValue(comments);
                } else {
                    liveData.postValue(comments);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }
    public LiveData<String> saveData(Comment comment,String storeId)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(storeId).child(comment.getId()).setValue(comment)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
}
