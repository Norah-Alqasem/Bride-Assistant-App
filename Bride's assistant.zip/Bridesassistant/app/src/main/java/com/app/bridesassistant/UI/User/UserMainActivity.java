package com.app.bridesassistant.UI.User;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.app.bridesassistant.R;
import com.app.bridesassistant.UI.Authentication.AuthMainActivity;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.Utils.LocalLanguage.HelperLocalLanguage;
import com.app.bridesassistant.databinding.ActivityUserMainBinding;
import com.google.android.material.navigation.NavigationBarView;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class UserMainActivity extends AppCompatActivity {
    private ActivityUserMainBinding mainBinding;
    private AppBarConfiguration mAppBarConfiguration;
    NavController navController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        HelperLocalLanguage.setLocale(this,"en");
        mainBinding=ActivityUserMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());
        setSupportActionBar(mainBinding.toolbar);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.stores,R.id.relatives,R.id.budget,
               R.id.profile,R.id.tasks,R.id.info)
                .build();
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_auth);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        Window window = getWindow();
        window.setStatusBarColor(getResources().getColor(R.color.color3));

        mainBinding.navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                 if(item.getItemId()==R.id.stores){
                     mainBinding.drawerLayout.setVisibility(View.GONE);
                     mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
                    navController.navigate(R.id.stores);
                }
                else if(item.getItemId()==R.id.task){
                     mainBinding.drawerLayout.setVisibility(View.GONE);
                     mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
                    navController.navigate(R.id.tasks);
                }
                 else if(item.getItemId()==R.id.WeddingInformation){
                     mainBinding.drawerLayout.setVisibility(View.GONE);
                     mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
                     navController.navigate(R.id.info);
                 }
                else if(item.getItemId()==R.id.menu){
                    mainBinding.drawerLayout.setVisibility(View.VISIBLE);
                    mainBinding.drawerLayout.openDrawer(GravityCompat.START);
                }
                return true;
            }
        });
        mainBinding.main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainBinding.drawerLayout.setVisibility(View.GONE);
                mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
            }
        });
        mainBinding.drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {
                mainBinding.drawerLayout.setVisibility(View.GONE);
                mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
        sideMenu();
    }
    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
    private void sideMenu() {
        View v = mainBinding.sideMenu.getHeaderView(0);
        v.findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Content.type=0;
                Content.categoryNum=0;
                warning("Are you sure you want to log out?");
            }
        });
        v.findViewById(R.id.profile).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.profile);
                mainBinding.drawerLayout.setVisibility(View.GONE);
                mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
            }
        });
        v.findViewById(R.id.guests).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.relatives);
                mainBinding.drawerLayout.setVisibility(View.GONE);
                mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
            }
        });
        v.findViewById(R.id.budget).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.budget);
                mainBinding.drawerLayout.setVisibility(View.GONE);
                mainBinding.drawerLayout.closeDrawer(GravityCompat.START);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Content.type=0;
    }
    private void warning(String message) {
        SweetAlertDialog warningDialog = SweetDialog.warningDialog(UserMainActivity.this, message);
        warningDialog.show();
        warningDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                warningDialog.dismiss();
                startActivity(new Intent(UserMainActivity.this, AuthMainActivity.class));
            }
        });
        warningDialog.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                warningDialog.dismiss();
            }
        });
    }
}