package com.app.bridesassistant.UI.Admin.Stores;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;


import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.StoreRepo;
import com.app.bridesassistant.UI.Admin.Adapters.AdminViewStoresAdapter;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentAdminViewStoresBinding;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AdminViewStoresFragment extends Fragment {
    private FragmentAdminViewStoresBinding mBinding;
    private SweetAlertDialog loading;
    private ArrayList<Store> stores,search=new ArrayList<>();
    private AdminViewStoresAdapter adapter;
    private StoreRepo repo;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding=FragmentAdminViewStoresBinding.inflate(inflater,container,false);
        stores=new ArrayList<>();
        adapter=new AdminViewStoresAdapter(getActivity(),stores);
        mBinding.stores.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.stores.setAdapter(adapter);
        mBinding.addStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateTo(R.id.action_stores_to_addingStore, new Bundle());
            }
        });
        funLoading();
        getAllStores();
        clickItem();
        clickSearch();
        return mBinding.getRoot();
    }

    private void getAllStores()
    {
        repo=new StoreRepo();
        repo.getAllStores().observe(getViewLifecycleOwner(),result->{
            loading.dismiss();
            stores.clear();
            stores.addAll(result);
            if (result.isEmpty())
            {
                mBinding.empty2.setVisibility(View.VISIBLE);
            }
            else {
                mBinding.empty2.setVisibility(View.GONE);
            }
            adapter.updateData(result);
        });
    }
    private void clickItem()
    {
        adapter.onclickItem(new AdminViewStoresAdapter.OnItemClickListener() {
            @Override
            public void update(int position) {
                Bundle b=new Bundle();
                b.putParcelable("store",stores.get(position));
                navigateTo(R.id.action_stores_to_updateStore,b);
            }

            @Override
            public void block(int position) {

                if (stores.get(position).isStatus()) {
                    alertDialog(stores.get(position).getStoreId()
                            , "Unblock the store", "Do you want to unblock this store?", false);

                } else {
                    alertDialog(stores.get(position).getStoreId()
                            , "Block the store", "Do you want to block this store?", true);
                }
            }
        });
    }

    private void alertDialog(String userId, String title, String message, boolean status) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message);
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                blockUser(userId,status );
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void blockUser(String id, boolean status) {
        repo.blockStore(id, status).observe(getViewLifecycleOwner(), i -> {
            if (i.equals("success")) {
                if (status) {
                    funLoginSuccessfully("Store has been successfully blocked.");
                } else {
                    funLoginSuccessfully("Store has been successfully unblocked.");
                }
            } else {
                if (status) {
                    funLoginField("Failed to block Store");
                } else {
                    funLoginField("Failed to unblock Store");
                }
            }
        });
    }
    private void clickSearch()
    {
        mBinding.search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //sto
                search(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void search(String string) {
        search.clear();
        for (Store s:stores)
        {
            if (s.getStoreName().contains(string))
            {
                search.add(s);
            }
        }
        adapter.updateData(search);
    }

    private void funLoginSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funLoginField(String message) {
        SweetAlertDialog field = SweetDialog.failed(getContext(), message);
        field.show();
        field.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                field.dismiss();
            }
        });
    }
    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void navigateTo(int id, Bundle b)
    {
        Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_auth).navigate(id,b);
    }
}