package com.app.bridesassistant.DataClass;

public class BudgetModel {
    private float totalAmount,spent;

    public BudgetModel() {
    }

    public BudgetModel(float totalAmount, float spent) {
        this.totalAmount = totalAmount;
        this.spent = spent;
    }

    public float getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(float totalAmount) {
        this.totalAmount = totalAmount;
    }

    public float getSpent() {
        return spent;
    }

    public void setSpent(float spent) {
        this.spent = spent;
    }
}
