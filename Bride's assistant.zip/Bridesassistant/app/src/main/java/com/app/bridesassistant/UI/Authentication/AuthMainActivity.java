package com.app.bridesassistant.UI.Authentication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.CategoriesRepo;
import com.app.bridesassistant.Repo.StoreRepo;
import com.app.bridesassistant.Utils.Dialoge.AlertDialogLogin;
import com.app.bridesassistant.Utils.EventBus.MessageEvent;
import com.app.bridesassistant.Utils.LocalLanguage.HelperLocalLanguage;
import com.app.bridesassistant.databinding.ActivityAuthMainBinding;
import com.google.android.material.navigation.NavigationBarView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.UUID;

public class AuthMainActivity extends AppCompatActivity {
    private ActivityAuthMainBinding mainBinding;
    private AppBarConfiguration mAppBarConfiguration;
    NavController navController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        HelperLocalLanguage.setLocale(this,"en");
        mainBinding=ActivityAuthMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());
        setSupportActionBar(mainBinding.toolbar);
        mAppBarConfiguration = new AppBarConfiguration.Builder()
                .build();
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_auth);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        Window window = getWindow();
        window.setStatusBarColor(getResources().getColor(R.color.color3));

        mainBinding.navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId()==R.id.login)
                {
                    navController.navigate(R.id.login);
                }
                else if(item.getItemId()==R.id.stores){
                    navController.navigate(R.id.stores);
                }
                else {
                    AlertDialogLogin.alertDialog(AuthMainActivity.this,R.id.login);
                }
                return true;
            }
        });
          //add();

        mainBinding.toolbar.setVisibility(View.GONE);
        mainBinding.navView.setVisibility(View.GONE);
        checkNotificationPermission();

    }
    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageEvent event) {
        // Handle the event
        //Toast.makeText(getContext(), event.getMessage(), Toast.LENGTH_SHORT).show();
        if (event.getMessage().equals("1"))
        {
            mainBinding.toolbar.setVisibility(View.VISIBLE);
            mainBinding.navView.setVisibility(View.VISIBLE);

        }
        else{
            mainBinding.toolbar.setVisibility(View.GONE);
            mainBinding.navView.setVisibility(View.GONE);
            navController.navigate(R.id.outer);
        }
    }
    private void checkNotificationPermission()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

            }
        }
    }
    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }
    private void add()
    {
        StoreRepo repo=new StoreRepo();
        for (Store s: addStores()) {
            repo.saveStoreData(s);
        }
    }
    private ArrayList<Category> addCtegories()
    {
        ArrayList<Category> categories=new ArrayList<>();
        categories.add(new Category("Wedding Dress Shops",UUID.randomUUID().toString()));
        categories.add(new Category("Makeup Artists",UUID.randomUUID().toString()));
        categories.add(new Category("Hair Stylists",UUID.randomUUID().toString()));
        categories.add(new Category("Bridesmaids' Dress",UUID.randomUUID().toString()));
        categories.add(new Category("Wedding Halls and Venues",UUID.randomUUID().toString()));
        categories.add(new Category("Bouquet and Flower Shops",UUID.randomUUID().toString()));
        categories.add(new Category("Wedding services and guest serving accounts",UUID.randomUUID().toString()));
        categories.add(new Category("Sweets and Savories Shops",UUID.randomUUID().toString()));
        categories.add(new Category("Buffet And Restaurants ",UUID.randomUUID().toString()));
        categories.add(new Category("Venue Decorator",UUID.randomUUID().toString()));
        categories.add(new Category("Artist/Singer/Musician",UUID.randomUUID().toString()));
        categories.add(new Category("Hospitality Services",UUID.randomUUID().toString()));
        categories.add(new Category("Gold and jewelry shops",UUID.randomUUID().toString()));

        return categories;
    }
    private ArrayList<Store> addStores()
    {
        ArrayList<Store> stores=new ArrayList<>();

        stores.add(new Store("La Femme", "", "sales@lafemme.com", "Dammam", "+966510123456", "Wedding Dress Shops", "@lafemme", "https://www.tiktok.com/@ikhfashion/video/7306226156552850695","26.42103632450577,50.08810691535473", UUID.randomUUID().toString(),1,5,5,false));
        stores.add(new Store("Moda Bella", "", "contact@modabella.com", "Dammam", "+966511234567", "Wedding Dress Shops", "@modabella", "https://www.tiktok.com/@ikhfashion/video/7306226156552850695","26.42103632450577,50.08810691535473", UUID.randomUUID().toString(),1,5,5,false));
        stores.add(new Store("Haute Couture", "", "info@hautecouture.com", "Dammam", "+966512345678", "Wedding Dress Shops", "@hautecouture", "https://www.tiktok.com/@ikhfashion/video/7306226156552850695","26.42103632450577,50.08810691535473", UUID.randomUUID().toString(),1,5,5,false));


        return stores;
    }

}