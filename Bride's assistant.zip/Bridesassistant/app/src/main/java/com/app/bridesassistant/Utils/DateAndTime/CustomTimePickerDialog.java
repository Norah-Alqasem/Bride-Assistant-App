package com.app.bridesassistant.Utils.DateAndTime;

import android.app.TimePickerDialog;
import android.content.Context;

public class CustomTimePickerDialog extends TimePickerDialog {

    public CustomTimePickerDialog(Context context, OnTimeSetListener listener, int hourOfDay, int minute, boolean is24HourView) {
        super(context, listener, hourOfDay, minute, is24HourView);
    }

    public CustomTimePickerDialog(Context context, int theme, OnTimeSetListener listener, int hourOfDay, int minute, boolean is24HourView) {
        super(context, theme, listener, hourOfDay, minute, is24HourView);
    }
}

