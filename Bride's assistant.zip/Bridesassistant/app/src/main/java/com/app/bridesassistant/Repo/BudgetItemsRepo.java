package com.app.bridesassistant.Repo;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.BudgetItemsModel;
import com.app.bridesassistant.DataClass.BudgetModel;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BudgetItemsRepo {
    private DatabaseReference database;

    public BudgetItemsRepo() {
        database=FirebaseDatabase.getInstance().getReference(Content.budgetItems);
    }
    public LiveData<List<BudgetItemsModel>> get(String userId)
    {
        MutableLiveData<List<BudgetItemsModel>> liveData=new MutableLiveData<>();
        ArrayList<BudgetItemsModel> arrayList=new ArrayList<>();
        database.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists())
                {
                    for (DataSnapshot data:snapshot.getChildren()) {
                        BudgetItemsModel c = data.getValue(BudgetItemsModel.class);
                        arrayList.add(c);
                    }
                    liveData.postValue(arrayList);
                }
                else{
                    liveData.postValue(arrayList);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }
    public LiveData<String> saveData(BudgetItemsModel b,String userid)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(userid).child(b.getId()).setValue(b)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
    public LiveData<String> delete(String b,String userid)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(userid).child(b).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }

}
