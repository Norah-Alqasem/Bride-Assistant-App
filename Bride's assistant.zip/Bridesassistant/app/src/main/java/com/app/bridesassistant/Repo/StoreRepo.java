package com.app.bridesassistant.Repo;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class StoreRepo {
    private DatabaseReference database;

    public StoreRepo() {
        database=FirebaseDatabase.getInstance().getReference(Content.storesTable);
    }
    public LiveData<ArrayList<Store>> getAllStores()
    {
        MutableLiveData<ArrayList<Store>> liveData=new MutableLiveData<>();
        ArrayList<Store>stores=new ArrayList<>();
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                stores.clear();
                if (snapshot.exists())
                {
                    for (DataSnapshot data:snapshot.getChildren()){
                        Store store=data.getValue(Store.class);
                        stores.add(store);
                    }
                    liveData.postValue(stores);
                }
                else{
                    liveData.postValue(stores);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }
    public LiveData<String> saveStoreData(Store store)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(store.getStoreId()).setValue(store)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
    public LiveData<String> blockStore(String id,boolean status)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(id).child("status").setValue(status).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                liveData.setValue("success");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                liveData.setValue("failed");
            }
        });
        return liveData;
    }
}
