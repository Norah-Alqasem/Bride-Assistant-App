package com.app.bridesassistant.UI.Admin.Users;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;


import com.app.bridesassistant.DataClass.User;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.UsersRepo;
import com.app.bridesassistant.UI.Admin.Adapters.AdminViewUsersAdapter;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentAdminViewUsersBinding;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AdminViewUsersFragment extends Fragment {
    private FragmentAdminViewUsersBinding mBinding;
    private SweetAlertDialog loading;
    private ArrayList<User> users,search=new ArrayList<>();
    private AdminViewUsersAdapter adapter;
    private UsersRepo repo;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding=FragmentAdminViewUsersBinding.inflate(inflater,container,false);

        users=new ArrayList<>();
        adapter=new AdminViewUsersAdapter(getActivity(),users);
        mBinding.users.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.users.setAdapter(adapter);
        funLoading();
        getAllUsers();
        clickItem();
        clickSearch();
        return mBinding.getRoot();
    }

    private void getAllUsers()
    {
        repo=new UsersRepo();
        repo.getAllUsers().observe(getViewLifecycleOwner(),result->{
            loading.dismiss();
            users.clear();
            users.addAll(result);
            if (result.isEmpty())
            {
                mBinding.empty2.setVisibility(View.VISIBLE);
            }
            else {
                mBinding.empty2.setVisibility(View.GONE);
            }
            adapter.updateData(result);
        });
    }
    private void clickItem()
    {
        adapter.onclickItem(new AdminViewUsersAdapter.OnItemClickListener() {
            @Override
            public void block(int position) {

                if (users.get(position).isStatus()) {
                    alertDialog(users.get(position).getUserId()
                            , "Unblock the user", "Do you want to unblock this user?", false);

                } else {
                    alertDialog(users.get(position).getUserId()
                            , "Block the user", "Do you want to block this user?", true);
                }
            }
        });
    }

    private void alertDialog(String userId, String title, String message, boolean status) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message);
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                blockUser(userId,status );
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void blockUser(String id, boolean status) {
        repo.blockUser(id, status).observe(getViewLifecycleOwner(), i -> {
            if (i.equals("success")) {
                if (status) {
                    funLoginSuccessfully("user has been successfully blocked.");
                } else {
                    funLoginSuccessfully("user has been successfully unblocked.");
                }
            } else {
                if (status) {
                    funLoginField("Failed to block user");
                } else {
                    funLoginField("Failed to unblock user");
                }
            }
        });
    }
    private void clickSearch()
    {
        mBinding.search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                search(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void search(String string) {
        search.clear();
        for (User s:users)
        {
            if (s.getUserName().contains(string))
            {
                search.add(s);
            }
        }
        adapter.updateData(search);
    }


    private void funLoginSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funLoginField(String message) {
        SweetAlertDialog field = SweetDialog.failed(getContext(), message);
        field.show();
        field.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                field.dismiss();
            }
        });
    }
    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }
}