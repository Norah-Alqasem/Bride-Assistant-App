package com.app.bridesassistant.UI.Authentication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.app.bridesassistant.R;
import com.app.bridesassistant.UI.Admin.AdminMainActivity;
import com.app.bridesassistant.UI.User.UserMainActivity;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentLoginBinding;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class LoginFragment extends Fragment {
    private FragmentLoginBinding mBinding;
    private FirebaseAuth auth;
    private int pStatus=1;
    private SweetAlertDialog loading;
    private boolean isLogin=false;
    private DatabaseReference database;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentLoginBinding.inflate(inflater, container, false);

        auth = FirebaseAuth.getInstance();
        mBinding.signinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBinding.signInEmail.getText().toString().equals("admin@gmail.com")&&mBinding.signInPassword.getText().toString().equals("12345678"))
                    startActivity(new Intent(getActivity(), AdminMainActivity.class));
                else{
                    checkEnteredData();
                }
            }
        });
        showPassword();
        return mBinding.getRoot();
    }
    private void checkEnteredData()
    {
        String email=mBinding.signInEmail.getText().toString();
        String password=mBinding.signInPassword.getText().toString();
        if (email.isEmpty())
        {
            mBinding.signInEmail.setError("Enter your email");
        }
        else if (password.isEmpty())
        {
            mBinding.signInPassword.setError("Enter your password");
        }
        else{
            funLoading();
            checkIfUser(email,password);
        }
    }
    private void checkIfUser(String email,String password)
    {
        auth.signInWithEmailAndPassword(email,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                checkIfUserBlock(authResult.getUser().getUid().toString());
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                loading.dismiss();
                funFailed("Sorry, we couldn't find your account.");

            }
        });
    }
    private void checkIfUserBlock(String id) {
        database=FirebaseDatabase.getInstance().getReference();
        database.child(Content.userTable).child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()&&!isLogin) {
                    loading.dismiss();
                    boolean status = Boolean.parseBoolean(snapshot.child("status").getValue().toString());
                    if (status) {
                        funFailed("Sorry, the administrator has banned your account from the application.");
                    } else {
                        isLogin=true;
                        Content.type=1;
                        Content.categoryNum=0;
                        funSuccessfully("You have successfully logged in.");
                        startActivity(new Intent(getActivity(), UserMainActivity.class));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void showPassword() {
        mBinding.showPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pStatus == 1) {
                    Glide.with(getActivity())
                            .load(R.drawable.baseline_visibility_24)
                            .centerCrop()
                            .into(mBinding.showPassword);
                    pStatus = 0;
                    mBinding.signInPassword.setInputType(InputType.TYPE_CLASS_TEXT);
                } else {
                    Glide.with(getActivity())
                            .load(R.drawable.baseline_visibility_off_24)
                            .centerCrop()
                            .into(mBinding.showPassword);
                    pStatus = 1;
                    mBinding.signInPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
            }
        });
    }
    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }
    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funFailed(String message) {
        SweetAlertDialog failed = SweetDialog.failed(getContext(), message);
        failed.show();
        failed.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                failed.dismiss();
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mBinding.signUpLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_login_to_registration);
            }
        });
        mBinding.forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_login_to_resetPassword);
            }
        });
    }
}