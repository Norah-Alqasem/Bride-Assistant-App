package com.app.bridesassistant.UI.User.Tasks;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;


import com.app.bridesassistant.Alarm.RegisterTimesWorker;
import com.app.bridesassistant.DataClass.TaskDataclass;
import com.app.bridesassistant.Repo.TasksRepo;
import com.app.bridesassistant.UI.User.Adapters.TasksAdapter;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.DateAndTime.CustomDatePickerDialog;
import com.app.bridesassistant.Utils.DateAndTime.CustomTimePickerDialog;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentTasksBinding;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class TasksFragment extends Fragment {
    private FragmentTasksBinding mBinding;
    private TasksAdapter adapter;
    private String userId;
    private SweetAlertDialog loading;
    private ArrayList<TaskDataclass> arrayList;
    private TasksRepo repo;
    private int type=0;
    private TaskDataclass task;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentTasksBinding.inflate(inflater, container, false);
        mBinding.date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });
        mBinding.time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelectedTime();
            }
        });
        funLoading();
        repo=new TasksRepo();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
        clickAdd();
        defineItems();
        clickItem();
        return mBinding.getRoot();
    }

    private void defineItems() {
        arrayList = new ArrayList<>();
        adapter = new TasksAdapter(getActivity(), arrayList);
        mBinding.tasks.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.tasks.setAdapter(adapter);
        getDataFromFirebase();
    }

    private void getDataFromFirebase() {
        repo.getAllCTasks(userId).observe(getViewLifecycleOwner(),tasks->{
            loading.dismiss();
            arrayList.clear();
            arrayList.addAll(tasks);
            if (arrayList.isEmpty())
                mBinding.empty.setVisibility(View.VISIBLE);
            else
                mBinding.empty.setVisibility(View.GONE);
            createAlarm();
            adapter.notifyDataSetChanged();
        });
    }
    private void clickAdd() {
        mBinding.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = mBinding.name.getText().toString();
                String time = mBinding.time.getText().toString();
                String date = mBinding.date.getText().toString();
                if (name.isEmpty()) {
                    mBinding.name.setError("Please enter the task Name");
                } else if (time.isEmpty()) {
                    mBinding.time.setError("Please enter the task time");
                } else if (date.isEmpty()) {
                    mBinding.date.setError("Please enter the task date");
                } else {
                    funLoading();
                    if (type == 1) {
                        task.setTaskDate(date);
                        task.setTaskName(name);
                        task.setTaskTime(time);
                        saveToDatabase(task);
                    } else {
                        String id = UUID.randomUUID().toString();
                        TaskDataclass dataClass = new TaskDataclass(name, time, date, id);
                        saveToDatabase(dataClass);
                    }
                }
            }
        });
    }

    private void saveToDatabase(TaskDataclass dataClass) {
        repo.saveTaskData(dataClass,userId).observe(getViewLifecycleOwner(),result->
        {
            loading.dismiss();
            if (result.equals("failed")) {
                if (type == 1) {
                    funField("Failed to Update task please try again ");
                } else {
                    funField("Failed to add task please try again ");
                }
            }
            else {
                if (type == 1) {
                    funSuccessfully("Update successfully");
                } else {
                    funSuccessfully("adding successfully");
                }
            }
        });
    }
    private void clickItem()
    {
        adapter.setOnItemClickListener(new TasksAdapter.OnItemClickListener() {
            @Override
            public void update(int pos) {
                task=arrayList.get(pos);
                type=1;
                mBinding.date.setText(task.getTaskDate());
                mBinding.time.setText(task.getTaskTime());
                mBinding.name.setText(task.getTaskName());
                mBinding.addButton.setText("Update");
            }

            @Override
            public void delete(int pos) {
                alertDialog(pos,"Delete task","Are you sure you need to Delete this task?");

            }
        });
    }

    private void alertDialog(int position,String title,String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message);
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                deleteItem(position,title);
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void deleteItem(int position,String title) {
        repo.deleteTaskData(arrayList.get(position).getTaskId(),userId).observe(getViewLifecycleOwner(),result->
        {
            loading.dismiss();
            if (result.equals("failed"))
            {
                funField("Failed to "+title );
            }
            else {
                funSuccessfully(title+" Successfully");
            }
        });
    }
    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
        mBinding.time.setText("Task time");
        mBinding.date.setText("Task Date");
        mBinding.name.setText("");
        mBinding.addButton.setText("Add");
    }

    private void funField(String message) {
        SweetAlertDialog field = SweetDialog.failed(getContext(), message);
        field.show();
        field.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                field.dismiss();
            }
        });
    }
    private void createAlarm()
    {
        WorkManager.getInstance(getActivity().getApplicationContext()).cancelAllWork();
        PeriodicWorkRequest request=new PeriodicWorkRequest
                .Builder(RegisterTimesWorker.class,1, TimeUnit.HOURS)
                .addTag("Alarm")
                .build();
        WorkManager.getInstance(getActivity().getApplicationContext()).enqueueUniquePeriodicWork("Alarm"
                , ExistingPeriodicWorkPolicy.REPLACE,request);

    }
    private void setSelectedTime() {
        CustomTimePickerDialog timePickerDialog = new CustomTimePickerDialog(
                getActivity(),
                (view, hourOfDay, minute) -> {
                    // Handle time selection
                    mBinding.time.setText(hourOfDay + ":" + minute + ":00");
                    // time = hourOfDay + ":" + minute;
                },
                Calendar.getInstance().get(Calendar.HOUR),
                Calendar.getInstance().get(Calendar.MINUTE),
                false
        );

        timePickerDialog.show();
    }

    private void showDatePickerDialog() {
        CustomDatePickerDialog datePickerDialog = new CustomDatePickerDialog(
                getActivity(),
                (view, year, month, dayOfMonth) -> {
                    // Handle date selection
                    String monthStr=((month+1)<10)?"0"+(month+1): (month+1)+"";
                    String date = year + "/" + monthStr + "/" + dayOfMonth;
                    long delay= Content.getDaysReminders2(date);
                    if(delay>0) {
                        mBinding.date.setText(date);
                    }else{
                        funField("Please select a valid date");
                    }
                },
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        );

        datePickerDialog.show();
    }

}