package com.app.bridesassistant.DataClass;

public class RelativesDataClass {
    private String name,relationship,id;

    public RelativesDataClass() {
    }

    public RelativesDataClass(String name, String relationship, String id) {
        this.name = name;
        this.relationship = relationship;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
