package com.app.bridesassistant.UI.Admin;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.Repo.CategoriesRepo;
import com.app.bridesassistant.UI.Admin.Adapters.AdminCategoriesAdapter;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentAdminManageCategoriesBinding;

import java.util.ArrayList;
import java.util.UUID;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AdminManageCategories extends Fragment {
    private FragmentAdminManageCategoriesBinding mBinding;
    private SweetAlertDialog loading;
    private CategoriesRepo repo;
    private AdminCategoriesAdapter adapter;
    private ArrayList<Category> categories;
    private int type = 0;
    private Category updateCategory;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentAdminManageCategoriesBinding.inflate(inflater, container, false);

        repo = new CategoriesRepo();

        funLoading();
        defineResyclerview();
        addCategory();
        clickItem();
        return mBinding.getRoot();
    }

    private void defineResyclerview() {
        categories = new ArrayList<>();
        adapter = new AdminCategoriesAdapter(getActivity(), categories);
        mBinding.categories.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.categories.setAdapter(adapter);
        getAllCategories();
    }

    private void getAllCategories() {

        repo.getAllCategories().observe(getViewLifecycleOwner(), result -> {
            loading.dismiss();
            categories.clear();
            if (result.isEmpty()) {
                mBinding.empty2.setVisibility(View.VISIBLE);
            } else {
                mBinding.empty2.setVisibility(View.GONE);
                categories.addAll(result);
            }
            adapter.notifyDataSetChanged();
        });
    }

    private void clickItem() {
        adapter.setOnItemClickListener(new AdminCategoriesAdapter.OnItemClickListener() {
            @Override
            public void update(int pos) {
                mBinding.name.setText(categories.get(pos).getName());
                mBinding.addButton.setText("Update");
                type = 1;
                updateCategory = categories.get(pos);
            }

            @Override
            public void delete(int pos) {
                alertDialog(pos);
            }
        });
    }

    private void alertDialog(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(" Delete Category")
                .setMessage("are you sure you went to delete this category ?");
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                funLoading();
                deleteCategory(categories.get(position).getId());
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void deleteCategory(String id) {
        repo.deleteCategoryData(id).observe(getActivity(), result -> {
            loading.dismiss();
            if (result.equals("failed")) {
                funLoginField("Failed to delete Category Please change your email");
            } else {
                funLoginSuccessfully("delete Category successfully");
            }
        });
    }

    private void addCategory() {
        mBinding.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = mBinding.name.getText().toString();
                if (name.isEmpty()) {
                    mBinding.name.setError("Enter Category Name");
                } else {
                    funLoading();
                    if (type == 0) {
                        String id = UUID.randomUUID().toString();
                        Category category = new Category(name, id);
                        saveData(category);
                    } else {
                        updateCategory.setName(name);
                        saveData(updateCategory);
                    }
                }
            }
        });
    }

    private void saveData(Category category) {
        repo.saveCategoryData(category).observe(getActivity(), result -> {
            loading.dismiss();
            if (result.equals("failed")) {
                if (type == 0)
                    funLoginField("Failed to Add Category Please change your email");
                else
                    funLoginField("Failed to Update Category Please change your email");
            } else {
                if (type == 0)
                    funLoginSuccessfully("Add Category successfully");
                else
                    funLoginSuccessfully("Update Category successfully");
            }
        });
    }

    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funLoginSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
        type = 0;
        mBinding.addButton.setText("Add");
        mBinding.name.setText("");
    }

    private void funLoginField(String message) {
        SweetAlertDialog field = SweetDialog.failed(getContext(), message);
        field.show();
        field.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                field.dismiss();
            }
        });
    }
}