package com.app.bridesassistant.Repo;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.TaskDataclass;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TasksRepo {
    private DatabaseReference database;

    public TasksRepo() {
        database=FirebaseDatabase.getInstance().getReference(Content.taskTable);
    }
    public LiveData<ArrayList<TaskDataclass>> getAllCTasks(String userId)
    {
        MutableLiveData<ArrayList<TaskDataclass>> liveData=new MutableLiveData<>();
        ArrayList<TaskDataclass>tasks=new ArrayList<>();
        database.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tasks.clear();
                if (snapshot.exists())
                {
                    for (DataSnapshot data:snapshot.getChildren()){
                        TaskDataclass c=data.getValue(TaskDataclass.class);
                        tasks.add(c);
                    }
                    liveData.postValue(tasks);
                }
                else{
                    liveData.postValue(tasks);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }
    public LiveData<String> saveTaskData(TaskDataclass task,String userId)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(userId).child(task.getTaskId()).setValue(task)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
    public LiveData<String> deleteTaskData(String id,String userId)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(userId).child(id).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
}
