package com.app.bridesassistant.UI.Admin.Stores;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.CategoriesRepo;
import com.app.bridesassistant.Repo.StoreRepo;
import com.app.bridesassistant.UI.MapsFragment;
import com.app.bridesassistant.Utils.CheckPermissionToOpenGallery;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.Utils.Validation.ValidationPhoneNumber;
import com.app.bridesassistant.databinding.FragmentAdminUpdateStoreBinding;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AdminUpdateStoreFragment extends Fragment {
    private FragmentAdminUpdateStoreBinding mBinding;
    private Store store;
    private SweetAlertDialog loading;
    private ArrayList<String> categories;
    private String image = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentAdminUpdateStoreBinding.inflate(inflater, container, false);
        store = getArguments().getParcelable("store");
        mBinding.location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.layout,new MapsFragment()).commit();
            }
        });
        mBinding.createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkEnteredStoreData();
            }
        });

        mBinding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CheckPermissionToOpenGallery.checkThePermission(getActivity()))
                    openGallery();
            }
        });
        funLoading();
        getAllCategories();
        addDataToDesign();
        return mBinding.getRoot();
    }

    private void addDataToDesign() {
        mBinding.storeName.setText(store.getStoreName());
        mBinding.email.setText(store.getEmail());
        mBinding.storePhone.setText(store.getMobileNumber());
        mBinding.instaLink.setText(store.getInstaLink());
        mBinding.tiktokLink.setText(store.getTiktokLink());
        Content.location=store.getLocation();
        String[] addresses = getResources().getStringArray(R.array.address);
        for (int i = 0; i < addresses.length; i++) {
            if (addresses[i].equals(store.getAddress()))
                mBinding.storeAddress.setSelection(i);
        }
        image = store.getImage();
        if (!store.getImage().isEmpty())
        {
            image=store.getImage();
            Bitmap decodedBitmap = decodeBase64ToBitmap(store.getImage());
            mBinding.profileImage.setImageBitmap(decodedBitmap);
        }
    }

    private void getAllCategories() {

        categories = new ArrayList<>();
        CategoriesRepo repo = new CategoriesRepo();
        repo.getAllCategories().observe(getViewLifecycleOwner(), result -> {
            loading.dismiss();
            categories.add("Categories");
            int i = 0;
            for (int y = 0; y < result.size(); y++) {
                categories.add(result.get(y).getName());
                if (result.get(y).getName().toLowerCase().equals(store.getType().toLowerCase())) {
                    i = y + 1;
                    Log.e("size2", i + "");
                }
            }
            Log.e("size", i + "");
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, categories);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mBinding.storeType.setAdapter(adapter);
            mBinding.storeType.setSelection(i);
        });
    }

    private void checkEnteredStoreData() {
        String name = mBinding.storeName.getText().toString();
        String phone = mBinding.storePhone.getText().toString();
        String address = mBinding.storeAddress.getSelectedItem().toString();
        String storeType = mBinding.storeType.getSelectedItem().toString();
        String insta = mBinding.instaLink.getText().toString();
        String tiktok = mBinding.tiktokLink.getText().toString();
        if (categories.size() == 1) {
            funFailed("No categories found please add categories first");
        } else if (name.isEmpty()) {
            mBinding.storeName.setError("Add StoreName");
        } else if (!ValidationPhoneNumber.validatePhoneNumber(phone)) {
            mBinding.storePhone.setError("Please make sure the number is correct as it starts with (05) and consists of 10 digits.");
        } else if (insta.isEmpty()) {
            mBinding.instaLink.setError("Add instagram Link");
        } else if (tiktok.isEmpty()) {
            mBinding.tiktokLink.setError("Add tiktok link");
        } else if (Content.location.isEmpty()) {
            funFailed("Please select a location. ");
        }else {
            funLoading();
            store.setStoreName(name);
            store.setImage(image);
            store.setType(storeType);
            store.setAddress(address);
            store.setMobileNumber(phone);
            store.setInstaLink(insta);
            store.setTiktokLink(tiktok);
            store.setLocation(Content.location);
            saveStoreData();
        }
    }
    private void saveStoreData() {
        StoreRepo repo = new StoreRepo();
        repo.saveStoreData(store).observe(getViewLifecycleOwner(), status -> {
            loading.dismiss();
            if (status.equals("failed")) {
                funFailed("Failed to update account Please change your email");
            } else {
                funSuccessfully("Update account successfully");
            }
        });
    }

    private void openGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), 1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            Glide.with(getActivity()).load(data.getData().toString()).into(mBinding.profileImage);
            Uri selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImageUri);
                image = convertToBase64(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    private String convertToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private Bitmap decodeBase64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funFailed(String message) {
        SweetAlertDialog failed = SweetDialog.failed(getContext(), message);
        failed.show();
        failed.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                failed.dismiss();
            }
        });
    }

}