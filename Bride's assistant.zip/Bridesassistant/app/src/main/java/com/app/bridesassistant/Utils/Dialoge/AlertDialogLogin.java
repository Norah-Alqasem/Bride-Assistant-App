package com.app.bridesassistant.Utils.Dialoge;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import androidx.navigation.Navigation;


import com.app.bridesassistant.R;
import com.app.bridesassistant.UI.Authentication.AuthMainActivity;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AlertDialogLogin {
   static public void alertDialog(Context context,int navigate){
        SweetAlertDialog dialog = new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE);
        dialog.setTitleText("In order to benefit from the application's features, you must log in first.");
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setConfirmButton("Login Now", sweetAlertDialog ->{
            Navigation.findNavController((Activity) context, R.id.nav_host_fragment_activity_auth).navigate(navigate);
            dialog.dismiss();
        });
        dialog.setCancelButton("Cancel", sweetAlertDialog ->{
            dialog.dismiss();
        });
        dialog.show();
    }
    static public void alertDialogLogout(Context context){
        SweetAlertDialog dialog = new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE);
        dialog.setTitleText("Are you sure you want to log out?");
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setConfirmButton("Logout Now", sweetAlertDialog ->{
            context.startActivity(new Intent(context, AuthMainActivity.class));
            dialog.dismiss();
        });
        dialog.setCancelButton("Cancel", sweetAlertDialog ->{
            dialog.dismiss();
        });
        dialog.show();
    }
}
