package com.app.bridesassistant.Alarm;


import android.annotation.SuppressLint;
import android.content.Context;
import android.icu.util.Calendar;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.app.bridesassistant.DataClass.TaskDataclass;
import com.app.bridesassistant.Utils.Content;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class RegisterTimesWorker extends Worker {
    public RegisterTimesWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @SuppressLint("RestrictedApi")
    @RequiresApi(api = Build.VERSION_CODES.N)
    @NonNull
    @Override
    public Result doWork() {
        try {
            Calendar calendar = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                calendar = Calendar.getInstance();
            }
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE) ;
            int  seconds= calendar.get(Calendar.SECOND) ;
            ArrayList<TaskDataclass> times=new ArrayList<>();
            Log.e("hour",hour+"");
            String userId= FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
            DatabaseReference data=FirebaseDatabase.getInstance().getReference(Content.taskTable);
            data.child(userId).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists())
                    {
                        times.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            TaskDataclass  item = data.getValue(TaskDataclass.class);
                                times.add(item);
                        }
                        alarm(times,hour,minute,seconds);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

            return Result.failure();
        }catch (Exception e)
        {
            return Result.retry();
        }
    }

    private void alarm(ArrayList<TaskDataclass> times, int hour, int minute, int seconds) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            times.forEach(s ->{
                String alarmTime = "" + s.getTaskDate() + " " +s.getTaskName()+s.getTaskTime();//unique for every alarm
                String currentTime=hour+":"+minute+":"+seconds;
                long delay = Content.calculateDelay(currentTime, s.getTaskTime());
                Log.e("delay",delay+"");
                Log.e("current time",currentTime+"");
                Log.e("alarm time",s.getTaskTime()+"");

                if (delay > 0) {
                    Data input = new Data.Builder()
                            .putString("title", "You Have a task")
                            .putString("content", s.getTaskName())
                            .build();

                    OneTimeWorkRequest registerPrayerRequest = new OneTimeWorkRequest
                            .Builder(AlarmNotification.class)
                            .addTag(alarmTime)
                            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                            .setInputData(input)
                            .build();

                    WorkManager.getInstance(getApplicationContext())
                            .enqueueUniqueWork(alarmTime, ExistingWorkPolicy.REPLACE, registerPrayerRequest);
                }
            });
        }

    }
}

