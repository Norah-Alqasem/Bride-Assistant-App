package com.app.bridesassistant.Repo;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.RelativesDataClass;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RelativesRepo {
    private DatabaseReference database;

    public RelativesRepo() {
        database = FirebaseDatabase.getInstance().getReference(Content.relativesTable);
    }

    public LiveData<ArrayList<RelativesDataClass>> getAllRelatives(String userId) {
        MutableLiveData<ArrayList<RelativesDataClass>> liveData = new MutableLiveData<>();
        ArrayList<RelativesDataClass> relatives = new ArrayList<>();
        database.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                relatives.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot data : snapshot.getChildren()) {
                        RelativesDataClass c = data.getValue(RelativesDataClass.class);
                        relatives.add(c);
                    }
                    liveData.postValue(relatives);
                } else {
                    liveData.postValue(relatives);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }

    public LiveData<String> saveRelativeData(RelativesDataClass relative, String userId) {
        MutableLiveData<String> liveData = new MutableLiveData<>();
        database.child(userId).child(relative.getId()).setValue(relative)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }

    public LiveData<String> deleteRelativeData(String id, String userId) {
        MutableLiveData<String> liveData = new MutableLiveData<>();
        database.child(userId).child(id).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
}
