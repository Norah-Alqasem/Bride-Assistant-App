package com.app.bridesassistant.UI.Authentication;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.app.bridesassistant.DataClass.User;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.UsersRepo;
import com.app.bridesassistant.UI.User.UserMainActivity;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.Utils.Validation.EmailValidator;
import com.app.bridesassistant.Utils.Validation.PasswordValidation;
import com.app.bridesassistant.Utils.Validation.ValidationPhoneNumber;
import com.app.bridesassistant.databinding.FragmentRegistrationBinding;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class RegistrationFragment extends Fragment {
    private FragmentRegistrationBinding mBinding;
    private int pStatus = 1, pStatus2 = 1;
    private SweetAlertDialog loading;
    FirebaseAuth auth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentRegistrationBinding.inflate(inflater, container, false);

        auth = FirebaseAuth.getInstance();
        mBinding.createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    checkEnteredUserData();

            }
        });
        showPassword();
        showPassword2();
        return mBinding.getRoot();
    }

    private void checkEnteredUserData() {
        String name = mBinding.useName.getText().toString();
        String email = mBinding.userEmail.getText().toString();
        String password = mBinding.userPassword.getText().toString();
        String confirmPassword = mBinding.userConfirem.getText().toString();
        String phone = mBinding.userPhoneNumber.getText().toString();
        String address = mBinding.userAddress.getText().toString();
        if (name.isEmpty()) {
            mBinding.useName.setError("Add username");
        } else if (!EmailValidator.isValidEmail(email)) {
            mBinding.userEmail.setError("Please enter correct email 'user@gmail.com'");
        } else if (!ValidationPhoneNumber.validatePhoneNumber(phone)) {
            mBinding.userPhoneNumber.setError("Please make sure the number is correct as it starts with (05) and consists of 10 digits.");
        } else if (!PasswordValidation.validatePassword(password)) {
            mBinding.userPassword.setError("Please enter a strong password that contains uppercase letters, lowercase letters, numbers and symbols (at least 8 characters)");
        } else if (!confirmPassword.equals(password)) {
            mBinding.userConfirem.setError("Password does not match");
        } else if (address.isEmpty()) {
            mBinding.userAddress.setError("Add the title");
        } else {
            funLoading();
            User user = new User(name, email, password, phone, address, "", "", false);
            createAccount(email, password, user);
        }
    }

    private void createAccount(String email, String password, User user) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    user.setUserId(authResult.getUser().getUid().toString());
                    saveUserData(user);
                })
                .addOnFailureListener(e -> {
                    loading.dismiss();
                    funFailed("Failed to create account Please change your email");
                });
    }

    private void saveUserData(User user) {
        UsersRepo repo = new UsersRepo();
        repo.saveUserData(user).observe(getViewLifecycleOwner(), status -> {
            loading.dismiss();
            if (status.equals("failed")) {
                funFailed("Failed to create account Please change your email");
            } else {
                funSuccessfully("New account created successfully");
            }
        });
    }

    private void showPassword() {
        mBinding.showPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pStatus == 1) {
                    Glide.with(getActivity())
                            .load(R.drawable.baseline_visibility_24)
                            .centerCrop()
                            .into(mBinding.showPassword);
                    pStatus = 0;
                    mBinding.userPassword.setInputType(InputType.TYPE_CLASS_TEXT);
                } else {
                    Glide.with(getActivity())
                            .load(R.drawable.baseline_visibility_off_24)
                            .centerCrop()
                            .into(mBinding.showPassword);
                    pStatus = 1;
                    mBinding.userPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
            }
        });
    }

    private void showPassword2() {
        mBinding.showPassword2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pStatus2 == 1) {
                    Glide.with(getActivity())
                            .load(R.drawable.baseline_visibility_24)
                            .centerCrop()
                            .into(mBinding.showPassword2);
                    pStatus2 = 0;
                    mBinding.userConfirem.setInputType(InputType.TYPE_CLASS_TEXT);
                } else {
                    Glide.with(getActivity())
                            .load(R.drawable.baseline_visibility_off_24)
                            .centerCrop()
                            .into(mBinding.showPassword2);
                    pStatus2 = 1;
                    mBinding.userConfirem.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
            }
        });
    }





    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
        success.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                success.dismiss();
                Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_auth).navigate(R.id.action_registration_to_login);

            }
        });
    }

    private void funFailed(String message) {
        SweetAlertDialog failed = SweetDialog.failed(getContext(), message);
        failed.show();
        failed.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                failed.dismiss();
            }
        });
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mBinding.signUpLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_registration_to_login);

            }
        });
    }
}