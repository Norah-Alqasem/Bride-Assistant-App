package com.app.bridesassistant.UI.User.Budget;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.bridesassistant.DataClass.BudgetItemsModel;
import com.app.bridesassistant.DataClass.BudgetModel;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.BudgetItemsRepo;
import com.app.bridesassistant.Repo.BudgetRepo;
import com.app.bridesassistant.UI.User.Adapters.BudgetItemsAdapter;
import com.app.bridesassistant.UI.User.Adapters.RelativesAdapter;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentUserViewBudgetBinding;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.UUID;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class UserViewBudgetFragment extends Fragment {
    private FragmentUserViewBudgetBinding mBinding;
    private String userId;
    private SweetAlertDialog loading;
    private BudgetRepo repo;
    private BudgetItemsRepo itemsRepo;
    private BudgetModel budgetModel;
    private BudgetItemsAdapter adapter;
    private ArrayList<BudgetItemsModel> arrayList;
    private int spentAmount = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentUserViewBudgetBinding.inflate(inflater, container, false);
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
        mBinding.addTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkEnteredData();
            }
        });
        mBinding.addSpent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkEnteredData();
            }
        });
        mBinding.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkEnteredItemsData();
            }
        });
        repo = new BudgetRepo();
        itemsRepo = new BudgetItemsRepo();
        funLoading();
        defineItems();
        clickItem();
        getData();
        getDataFromFirebase();
        return mBinding.getRoot();
    }

    private void defineItems() {
        arrayList = new ArrayList<>();
        adapter = new BudgetItemsAdapter(getActivity(), arrayList);
        mBinding.items.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.items.setAdapter(adapter);
    }

    private void getDataFromFirebase() {
        itemsRepo.get(userId).observe(getViewLifecycleOwner(), d -> {
            spentAmount = 0;
            arrayList.clear();
            for (BudgetItemsModel item : d) {
                spentAmount += Integer.parseInt(item.getSpent());
                arrayList.add(item);
            }
            adapter.update(arrayList);
        });
    }

    private void checkEnteredData() {
        String total = mBinding.total.getText().toString();
        String spent = mBinding.spent.getText().toString();
        if (total.isEmpty()) {
            mBinding.total.setError("Add total Amount");
        } else if (spent.isEmpty()) {
            mBinding.spent.setError("Add Spent Amount");
        } else {
            funLoading();
            BudgetModel model = new BudgetModel(Float.parseFloat(total), Float.parseFloat(spent));
            saveData(model);
        }
    }

    private void checkEnteredItemsData() {
        String item = mBinding.item.getText().toString();
        String spent = mBinding.itemSpent.getText().toString();
        String totalSpent = mBinding.spent.getText().toString();
        int d = spentAmount + Integer.parseInt(spent);
        if (item.isEmpty()) {
            mBinding.total.setError("Add Item Name");
        } else if (spent.isEmpty()) {
            mBinding.spent.setError("Add Spent Amount");
        } else if (d > Float.parseFloat(totalSpent)) {
            funFailed("You cannot add. You have exceeded the audio. Please increase the amount spent so that you can add.");
        } else {
            funLoading();
            BudgetItemsModel model = new BudgetItemsModel(item, spent, UUID.randomUUID().toString());
            saveItemsData(model);
        }
    }

    private void saveData(BudgetModel model) {

        repo.saveData(model, userId).observe(getViewLifecycleOwner(), status -> {
            loading.dismiss();
            if (status.equals("failed")) {
                funFailed("Failed to update Budget ");
            } else {
                funSuccessfully("Update budget successfully");
            }
        });
    }

    private void saveItemsData(BudgetItemsModel model) {
        itemsRepo.saveData(model, userId).observe(getViewLifecycleOwner(), status -> {
            loading.dismiss();
            if (status.equals("failed")) {
                funFailed("Failed to Add Item");
            } else {
                funSuccessfully("Add item successfully");
                mBinding.itemSpent.setText("");
                mBinding.item.setText("");
            }
        });
    }

    private void getData() {
        repo.get(userId).observe(getViewLifecycleOwner(), result -> {
            loading.dismiss();
            budgetModel = result;
            if (budgetModel != null) {
                addDataToDesign();
            } else {
                mBinding.addSpent.setText("Add");
                mBinding.addTotal.setText("Add");
                budgetModel.setSpent(1);
                budgetModel.setTotalAmount(1);
            }
            setupPieChart();
        });
    }

    private void addDataToDesign() {
        mBinding.total.setText(budgetModel.getTotalAmount() + "");
        mBinding.spent.setText(budgetModel.getSpent() + "");
        mBinding.addSpent.setText("Update");
        mBinding.addTotal.setText("Update");

    }

    private void setupPieChart() {
        // Create data entries
        float reminder = budgetModel.getTotalAmount() - budgetModel.getSpent();
        mBinding.spentText.setText("Spent " + budgetModel.getSpent() + " SAR");
        mBinding.reminder.setText("reminder " + reminder + " SAR");

        ArrayList<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(budgetModel.getSpent(), "Spent"));
        entries.add(new PieEntry(reminder, "Remaining"));

        // Define colors (similar to the image)
        int[] colors = new int[]{
                getResources().getColor(R.color.color2), getResources().getColor(R.color.color3)
        };

        // Create dataset
        PieDataSet pieDataSet = new PieDataSet(entries, "");
        pieDataSet.setColors(colors);
        pieDataSet.setValueTextSize(12f); // Hide values from the slices

        // Create PieData
        PieData pieData = new PieData(pieDataSet);
        mBinding.pieChart.setData(pieData);
        mBinding.pieChart.invalidate(); // Refresh chart

        // Customize Pie Chart
        mBinding.pieChart.setUsePercentValues(true);
        mBinding.pieChart.getDescription().setEnabled(false);
        mBinding.pieChart.setDrawEntryLabels(false); // Hide labels inside slices
        mBinding.pieChart.setHoleRadius(0f); // Donut shape
        mBinding.pieChart.setTransparentCircleRadius(0f);

        // Customize legend (disable it)
        Legend legend = mBinding.pieChart.getLegend();
        legend.setEnabled(false);

        // Add animation
        mBinding.pieChart.animateY(1000);
    }

    private void clickItem() {
        adapter.setOnItemClickListener(new BudgetItemsAdapter.OnItemClickListener() {
            @Override
            public void delete(int pos) {
                alertDialog(pos, "Delete Item", "Are you sure you need to Delete this Item?");
            }
        });
    }

    private void alertDialog(int position, String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message);
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                deleteItem(position, title);
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void deleteItem(int position, String title) {
        itemsRepo.delete(arrayList.get(position).getId(), userId).observe(getViewLifecycleOwner(), result ->
        {
            loading.dismiss();
            if (result.equals("failed")) {
                funFailed("Failed to" + title);
            } else {
                funSuccessfully(title + " Successfully");
                getDataFromFirebase();
            }
        });
    }

    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funFailed(String message) {
        SweetAlertDialog failed = SweetDialog.failed(getContext(), message);
        failed.show();
        failed.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                failed.dismiss();
            }
        });
    }
}