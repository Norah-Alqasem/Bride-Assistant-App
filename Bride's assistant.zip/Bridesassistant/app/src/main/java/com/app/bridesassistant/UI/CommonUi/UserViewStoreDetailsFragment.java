package com.app.bridesassistant.UI.CommonUi;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import com.app.bridesassistant.DataClass.Comment;
import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.DataClass.User;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.CommentRepo;
import com.app.bridesassistant.Repo.StoreRepo;
import com.app.bridesassistant.Repo.UsersRepo;
import com.app.bridesassistant.UI.CommonUi.Adapters.CommentsAdapter;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.Dialoge.AlertDialogLogin;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.databinding.FragmentUserViewStoreDetailsBinding;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.UUID;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class UserViewStoreDetailsFragment extends Fragment {
    private FragmentUserViewStoreDetailsBinding mBinding;
    private SweetAlertDialog loading;
    private CommentsAdapter adapter;
    private ArrayList<Comment> arrayList;
    private Store store;
    private CommentRepo repo;
    private UsersRepo usersRepo;
    private String userid;
    private User userModel;
    private StoreRepo storeRepo;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentUserViewStoreDetailsBinding.inflate(inflater, container, false);
        funLoading();
        storeRepo=new StoreRepo();
        arrayList = new ArrayList<>();
        adapter = new CommentsAdapter(arrayList);
        mBinding.comments.setLayoutManager(new LinearLayoutManager(getActivity()));
        mBinding.comments.setAdapter(adapter);
        mBinding.comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Content.type == 1) {
                    comment();
                } else {
                    AlertDialogLogin.alertDialog(getActivity(), R.id.login);
                }
            }
        });
        mBinding.rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Content.type == 1) {
                    rating();
                } else {
                    AlertDialogLogin.alertDialog(getActivity(), R.id.login);
                }
            }
        });
        mBinding.location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayLocation(store.getLocation(),store.getStoreName());
            }
        });
        if (Content.type == 1) {
            userid= FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
            getUserData();
        }
        addDataToDesign();
        return mBinding.getRoot();
    }
    private void getUserData()
    {
        usersRepo=new UsersRepo();
        usersRepo.getUserData(userid).observe(getViewLifecycleOwner(),d->{
            userModel=d;
        });
    }
    private void addDataToDesign() {
        store = getArguments().getParcelable("data");
        if (!store.getImage().isEmpty()) {
            Bitmap decodedBitmap = decodeBase64ToBitmap(store.getImage());
            mBinding.image.setImageBitmap(decodedBitmap);
        }
        mBinding.name.setText(store.getStoreName());
        mBinding.address.setText(store.getAddress());
        mBinding.type.setText(store.getType());
        getAllComments(store.getStoreId());
    }

    private void getAllComments(String storeId) {
        repo = new CommentRepo();
        repo.getAllComments(storeId).observe(getViewLifecycleOwner(), result -> {
            loading.dismiss();
            arrayList.clear();
            arrayList.addAll(result);
            if (arrayList.isEmpty()) {
                mBinding.empty2.setVisibility(View.VISIBLE);
                mBinding.comments.setVisibility(View.GONE);
            } else {
                mBinding.empty2.setVisibility(View.GONE);
                mBinding.comments.setVisibility(View.VISIBLE);
            }
            adapter.notifyDataSetChanged();
        });
    }

    private Bitmap decodeBase64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

    private void rating() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.rating_layout, null);

        // Create an AlertDialog builder and set the custom view
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        dialogBuilder.setView(dialogView);

        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
        Button send = dialogView.findViewById(R.id.send);
        RatingBar ratingBar = dialogView.findViewById(R.id.ratingBar);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                ratingStore(store,ratingBar.getRating());
            }
        });

    }
    private void ratingStore(Store s, float rating)
    {
        int num=s.getNumberOfRatings()+1;//77
        float sum=s.getSumOfRatings()+rating;//300
        float r=sum / num;//300/77
        s.setSumOfRatings(sum);
        s.setNumberOfRatings(num);
        s.setRating(r);
        storeRepo.saveStoreData(s).observe(getViewLifecycleOwner(),result->{
            loading.dismiss();
            funSuccessfully("Send Rating Successfully");
        });

    }

    private void comment() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.comment_layout, null);

        // Create an AlertDialog builder and set the custom view
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        dialogBuilder.setView(dialogView);

        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
        Button send = dialogView.findViewById(R.id.send);
        EditText comment = dialogView.findViewById(R.id.comment);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String cStr=comment.getText().toString();
                if (cStr.isEmpty())
                {
                    comment.setError("Enter Your Comment");
                }
                else{
                    String id= UUID.randomUUID().toString();
                    Comment c=new Comment(cStr,userid,userModel.getUserName(),userModel.getImage(),Content.getCurrentDate(),id);
                    saveData(c);
                    dialog.dismiss();
                }
            }
        });

    }

    private void saveData(Comment c) {
        funLoading();
        repo.saveData(c,store.getStoreId()).observe(getViewLifecycleOwner(),d->{
            loading.dismiss();
            if (d.equals("failed")) {
                funFailed("Failed to add Comment please try again");
            } else {
                funSuccessfully("Add Comment successfully");
            }
        });
    }
    private void displayLocation(String loc,String userName) {
        //444.99999,8888888
        String[] parts = loc.split(",");
        LatLng location = new LatLng(Double.parseDouble(parts[0]), Double.parseDouble(parts[1]));
        Uri gmmIntentUri = Uri.parse("geo:" + location.latitude + "," + location.longitude + "?q=" + Uri.encode(userName));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            Toast.makeText(getActivity(), "You Don't have google map in your app", Toast.LENGTH_SHORT).show();
        }
    }
    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funFailed(String message) {
        SweetAlertDialog failed = SweetDialog.failed(getContext(), message);
        failed.show();
        failed.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                failed.dismiss();
            }
        });
    }
    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

}