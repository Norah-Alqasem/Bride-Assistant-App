package com.app.bridesassistant.Repo;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.User;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UsersRepo {
    private DatabaseReference database;

    public UsersRepo() {
        database=FirebaseDatabase.getInstance().getReference(Content.userTable);
    }
    public LiveData<ArrayList<User>> getAllUsers()
    {
        MutableLiveData<ArrayList<User>> liveData=new MutableLiveData<>();
        ArrayList<User>users=new ArrayList<>();
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                users.clear();
                if (snapshot.exists())
                {
                    for (DataSnapshot data:snapshot.getChildren()){
                        User user=data.getValue(User.class);
                        users.add(user);
                    }
                    liveData.postValue(users);
                }
                else{
                    liveData.postValue(users);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }
    public LiveData<String> saveUserData(User user)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(user.getUserId()).setValue(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
    public LiveData<User> getUserData(String  userId)
    {
        MutableLiveData<User> liveData=new MutableLiveData<>();
        database.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User u=snapshot.getValue(User.class);
                liveData.postValue(u);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return liveData;
    }
    public LiveData<String> blockUser(String id,boolean status)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(id).child("status").setValue(status).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                liveData.setValue("success");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                liveData.setValue("failed");
            }
        });
        return liveData;
    }
}
