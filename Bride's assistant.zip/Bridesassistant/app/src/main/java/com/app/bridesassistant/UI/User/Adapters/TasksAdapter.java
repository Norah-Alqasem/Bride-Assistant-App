package com.app.bridesassistant.UI.User.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bridesassistant.DataClass.TaskDataclass;
import com.app.bridesassistant.R;

import java.util.ArrayList;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.helper> {
    private OnItemClickListener mListener;
    public interface OnItemClickListener{
        void update(int pos);
        void delete(int pos);
    }
    public void setOnItemClickListener(OnItemClickListener mListener)
    {
        this.mListener=mListener;
    }
    ArrayList<TaskDataclass> arrayList;
    Context context;
    public TasksAdapter(Context context, ArrayList<TaskDataclass> arrayList) {
        this.context = context;
        this.arrayList=arrayList;
    }

    @NonNull
    @Override
    public helper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_tasks, parent, false);
        return new helper(v);
    }

    @Override
    public void onBindViewHolder(@NonNull helper holder, int position) {
        TaskDataclass task=arrayList.get(position);
        holder.date.setText(task.getTaskDate()+" "+task.getTaskTime());
        holder.taskName.setText(task.getTaskName());
        holder.update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.update(position);
            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.delete(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class helper extends RecyclerView.ViewHolder {
        TextView taskName,date;
        Button delete, update;
        public helper(@NonNull View itemView) {
            super(itemView);
            taskName=itemView.findViewById(R.id.taskName);
            date=itemView.findViewById(R.id.date);
            delete=itemView.findViewById(R.id.delete);
            update =itemView.findViewById(R.id.update);
        }
    }
}
