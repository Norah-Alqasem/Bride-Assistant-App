package com.app.bridesassistant.UI.Admin.Stores;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.DataClass.Store;
import com.app.bridesassistant.R;
import com.app.bridesassistant.Repo.CategoriesRepo;
import com.app.bridesassistant.Repo.StoreRepo;
import com.app.bridesassistant.UI.MapsFragment;
import com.app.bridesassistant.Utils.CheckPermissionToOpenGallery;
import com.app.bridesassistant.Utils.Content;
import com.app.bridesassistant.Utils.Dialoge.SweetDialog;
import com.app.bridesassistant.Utils.Validation.EmailValidator;
import com.app.bridesassistant.Utils.Validation.ValidationPhoneNumber;
import com.app.bridesassistant.databinding.FragmentAdminAddingStoreBinding;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AdminAddingStoreFragment extends Fragment {
    private FragmentAdminAddingStoreBinding mBinding;
    private SweetAlertDialog loading;
    private ArrayList<String> categories;
    private String image = "";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinding = FragmentAdminAddingStoreBinding.inflate(inflater, container, false);
        mBinding.location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.layout,new MapsFragment()).commit();
            }
        });
        mBinding.createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkEnteredStoreData();
            }
        });

        mBinding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CheckPermissionToOpenGallery.checkThePermission(getActivity()))
                    openGallery();
            }
        });
        funLoading();
        getAllCategories();


        return mBinding.getRoot();
    }

    private void getAllCategories() {
        categories = new ArrayList<>();
        CategoriesRepo repo = new CategoriesRepo();
        repo.getAllCategories().observe(getViewLifecycleOwner(), result -> {
            loading.dismiss();
            categories.add("Categories");
            for (Category c : result) {
                categories.add(c.getName());
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, categories);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mBinding.storeType.setAdapter(adapter);
        });
    }

    private void checkEnteredStoreData() {
        String name = mBinding.storeName.getText().toString();
        String email = mBinding.storeEmail.getText().toString();
        String phone = mBinding.storePhone.getText().toString();
        String address = mBinding.storeAddress.getSelectedItem().toString();
        String storeType = mBinding.storeType.getSelectedItem().toString();
        String insta = mBinding.instaLink.getText().toString();
        String tiktok = mBinding.tiktokLink.getText().toString();
        if (categories.size()==1)
        {
            funFailed("No categories found, please add categories first");
        }
        else if (name.isEmpty()) {
            mBinding.storeName.setError("Add StoreName");
        } else if (!EmailValidator.isValidEmail(email)) {
            mBinding.storeEmail.setError("Please enter correct email 'store@gmail.com'");
        }  else if (!ValidationPhoneNumber.validatePhoneNumber(phone)) {
            mBinding.storePhone.setError("Please make sure the number is correct as it starts with (05) and consists of 10 digits.");
        }else if (insta.isEmpty()) {
            mBinding.instaLink.setError("Add instagram Link");
        }else if (tiktok.isEmpty()) {
            mBinding.tiktokLink.setError("Add tiktok link");
        } else if (Content.location.isEmpty()) {
            funFailed("Please select a location. ");
        } else {
            funLoading();
            String id= UUID.randomUUID().toString();
            Store store = new Store(name, image, email, address, phone,storeType,insta,tiktok,Content.location, id, 1,4.7f,4.7f, false);
            saveStoreData( store);
        }
    }


    private void saveStoreData(Store store) {
        StoreRepo repo = new StoreRepo();
        repo.saveStoreData(store).observe(getViewLifecycleOwner(), status -> {
            loading.dismiss();
            if (status.equals("failed")) {
                funFailed("Failed to add Store please try again");
            } else {
                funSuccessfully("New account created successfully");
            }
        });
    }


    private void openGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), 1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Glide.with(getActivity()).load(data.getData().toString()).into(mBinding.profileImage);
                Uri selectedImageUri = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImageUri);
                    image = convertToBase64(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }
    private String convertToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void funLoading() {
        loading = SweetDialog.loading(getContext());
        loading.show();
    }

    private void funSuccessfully(String title) {
        SweetAlertDialog success = SweetDialog.success(getContext(), title);
        success.show();
    }

    private void funFailed(String message) {
        SweetAlertDialog failed = SweetDialog.failed(getContext(), message);
        failed.show();
        failed.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                failed.dismiss();
            }
        });
    }


}