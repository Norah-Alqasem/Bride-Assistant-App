package com.app.bridesassistant.Repo;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bridesassistant.DataClass.Category;
import com.app.bridesassistant.Utils.Content;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CategoriesRepo {
    private DatabaseReference database;

    public CategoriesRepo() {
        database=FirebaseDatabase.getInstance().getReference(Content.categoriesTable);
    }
    public LiveData<ArrayList<Category>> getAllCategories()
    {
        MutableLiveData<ArrayList<Category>> liveData=new MutableLiveData<>();
        ArrayList<Category>categories=new ArrayList<>();
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                categories.clear();
                if (snapshot.exists())
                {
                    for (DataSnapshot data:snapshot.getChildren()){
                        Category c=data.getValue(Category.class);
                        categories.add(c);
                    }
                    liveData.postValue(categories);
                }
                else{
                    liveData.postValue(categories);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return liveData;
    }
    public LiveData<String> saveCategoryData(Category category)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(category.getId()).setValue(category)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
    public LiveData<String> deleteCategoryData(String id)
    {
        MutableLiveData<String> liveData=new MutableLiveData<>();
        database.child(id).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        liveData.setValue("success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        liveData.setValue("failed");
                    }
                });
        return liveData;
    }
}
